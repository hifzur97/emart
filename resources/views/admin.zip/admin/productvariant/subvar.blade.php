@extends('admin.layouts.master-soyuz')
@section('title','Add Product Variant | ')
@section('body')
@component('admin.component.breadcumb',['thirdactive' => 'active'])
@slot('heading')
{{ __('Add Product Variant') }}
@endslot
@slot('menu2')
{{ __("Add Product Variant") }}
@endslot

@slot('button')
<div class="col-md-6">
  <div class="widgetbar">
  <a href="{{ route('add.var',$findpro->id) }}" class="btn btn-primary-rgba"><i class="feather icon-arrow-left mr-2"></i>{{ __("Back")}}</a>
  </div>
</div>
@endslot

@endcomponent
<div class="contentbar">
    <div class="row">
@if ($errors->any())  
  <div class="alert alert-danger" role="alert">
  @foreach($errors->all() as $error)     
  <p>{{ $error}}<button type="button" class="close" data-dismiss="alert" aria-label="Close">
  <span aria-hidden="true" style="color:red;">&times;</span></button></p>
      @endforeach  
  </div>
  @endif
  
    <!-- row started -->
    <div class="col-lg-12">
    
        <div class="card m-b-30">
                <!-- Card header will display you the heading -->
                <div class="card-header">
                    <h5 class="card-box">Add Product Variant For <b>{{ $findpro->name }}</b></h5>
                </div> 
               
                <!-- card body started -->
                <div class="card-body">
                <ul class="nav nav-tabs mb-3" id="defaultTab" role="tablist">
                        <li class="nav-item">
                            <a class="nav-link active" id="home-tab" data-toggle="tab" href="#facebook" role="tab" aria-controls="home" aria-selected="true">{{ __('Add Variant') }}</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" id="profile-tab" data-toggle="tab" href="#google" role="tab" aria-controls="profile" aria-selected="false">{{ __('Pricing & Weight') }}</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" id="profile-tab" data-toggle="tab" href="#twitter" role="tab" aria-controls="profile" aria-selected="false">{{ __('Inventory') }}</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" id="profile-tab" data-toggle="tab" href="#linkedin" role="tab" aria-controls="profile" aria-selected="false">{{ __('Variant Images') }}</a>
                        </li>
                    </ul>
                    <div class="tab-content" id="defaultTabContent">

                        <!-- === language start ======== -->
                        <div class="tab-pane fade show active" id="facebook" role="tabpanel" aria-labelledby="home-tab">
                            <!-- === language form start ======== -->
                            <br>
                            <div class="box box-info">
                            <div class="box-header with-border">
                             
                              <label class="text-dark">
                              Add Stock
                                  </label>
                            </div>

                            <div class="box-body">
                              
                              <div class="row">
                                <div class="col-md-2">
                                  <label class="text-dark">
                                    Product Attributes:
                                  </label>
                                </div>

                              
                                <div class="col-md-10">
                                  @foreach($findpro->variants as $key=> $var)

                                <div class="panel panel-default">
                                  <div class="panel-heading">
                                    <label class="text-dark">
                                      <input required class="categories" type="checkbox" name="main_attr_id[]" id="categories_{{ $var->attr_name }}" child_id="{{$key}}" value="{{ $var->attr_name }}">
                                      
                                              @php
                                                  $key = '_'; 
                                              @endphp
                                              @if (strpos($var->getattrname->attr_name, $key) == false)
                                              
                                                {{ $var->getattrname->attr_name }}
                                                
                                              @else
                                                
                                                {{str_replace('_', ' ', $var->getattrname->attr_name)}}
                                                
                                              @endif
                                  </label>
                                  </div>

                                <div class="panel-body">
                                  @foreach($var->attr_value as $a => $value)
                                  @php
                                    $nameofvalue = App\ProductValues::where('id','=',$value)->first();
                                  @endphp
                                  <label class="text-dark">
                                    
                                    <input required class="a a_{{ $var->attr_name }}" parents_id="{{ $var->attr_name }}" value="{{ $value }}" type="radio" name="main_attr_value[{{$var->attr_name}}]" id="{{ $key }}">

                                      @if(strcasecmp($nameofvalue->unit_value, $nameofvalue->values) !=0)

                                        @if($var->getattrname->attr_name == "Color" || $var->getattrname->attr_name == "Colour")
                                          <div class="inline-flex">
                                              <div class="color-options">
                                             
                                              <p><a href="#" title=""><i style="color: {{ $nameofvalue->unit_value }}" class="fa fa-circle"></i></a></p>
                                              <span class="tx-color">{{ $nameofvalue->values }}</span>
                                                <!-- <ul>
                                                  <li title="{{ $nameofvalue->values }}" class="color varcolor active"><a href="#" title=""><i style="color: {{ $nameofvalue->unit_value }}" class="fa fa-circle"></i></a>
                                                          <div class="overlay-image overlay-deactive">
                                                          </div>
                                                    </li>
                                                </ul> -->
                                              </div>
                                          </div>
                                          <!-- <span class="tx-color">{{ $nameofvalue->values }}</span> -->
                                        @else
                                        {{ $nameofvalue->values }}{{ $nameofvalue->unit_value }}
                                        @endif
                                      @else
                                        {{ $nameofvalue->values }}
                                      @endif

                                  
                                  </label>
                                  @endforeach

                                </div>

                              </div>

                              @endforeach
                              
                              <label class="text-dark">Set Default Variant : 
                                  <input type="checkbox" name="def">
                                  </label>
                                

                              

                                </div>
                                
                              </div>
                              

                              
                            </div>
                          </div>
                            <!-- === language form end ===========-->    
                        </div>
                          <!-- === language end ======== -->

                          <!-- === frontstatic start ======== -->
                        <div class="tab-pane fade" id="google" role="tabpanel" aria-labelledby="profile-tab">
                            <!-- === frontstatic form start ======== -->

                            <div class="row">

                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label class="text-dark" for="">Additional Price For This Variant :</label>
                                        <input required value="{{ old('price') }}" placeholder="Enter Price ex 499.99" type="number" step=0.01 class="form-control" name="price">
                                        <small class="help-block">Please enter Price In Positive or Negative or zero<br></small>
                                        <!-- ------------------------------------ -->
                                        <div class="card bg-success-rgba m-b-30">
                                          <div class="card-body">
                                            <div class="row align-items-center">
                                              <div class="col-12">
                                                <h5 class="card-title text-primary mb-1"><i class="feather icon-alert-circle"></i> {{ __('Ex. :') }}</h5>
                                                <p class="mb-0 text-primary font-14"><b>Ex. </b>If you enter +10 and product price is 100 than price will be 110<br> OR <br>If you enter -10 and product price is 100 than price will be 90</p>
                                              </div>
                                            </div>
                                          </div>
                                        </div>
                                        <!--------------------------------------  -->
                                      </div>
                                </div>

                                <div class="col-md-3">
                                <div class="form-group">
                                    <label class="text-dark" for="weight">Weight:</label>
                                    <input type="number" step=0.01 name="weight" class="form-control" value="0.00" placeholder="0.00">
                                </div>
                                </div>

                                <div class="col-md-3">
                                <div class="form-group">
                                    <label class="text-dark" for="weight"></label>
                                    <select name="w_unit" class="select2 form-control">
                                      <option value="">Please Choose</option>
                                      @php
                                        $unit = App\Unit::find(1);
                                      @endphp
                                      @if(isset($unit))
                                        @foreach($unit->unitvalues as $unitVal)
                                            <option value="{{ $unitVal->id }}">{{ ucfirst($unitVal->short_code) }} ({{ $unitVal->unit_values }})</option>
                                        @endforeach
                                      @endif
                                    </select>
                                </div>
                                </div>

                            </div>

                            <!-- === frontstatic form end ===========-->
                        </div>
                        <!-- === frontstatic end ======== -->

                        <!-- === adminstatic start ======== -->
                        <div class="tab-pane fade" id="twitter" role="tabpanel" aria-labelledby="profile-tab">
                            <!-- === adminstatic form start ======== -->
                            <br>
                            <div class="row">
                                <div class="col-md-4">
                                <div class="form-group">
                                  <label class="text-dark" for="">Add Stock:</label>
                                  <input required min="1" type="number" class="form-control" name="stock" placeholder="Enter stock" value="{{ old('stock') }}" >
                                </div>
                                </div>

                                <div class="col-md-4">
                                <div class="form-group">
                                  <label class="text-dark" for="">Min Qty :</label>
                                  <input required value="{{ old('min_order_qty')  }}" min="1" type="number" class="form-control" name="min_order_qty" placeholder="Enter Min Qty For order">
                                </div>
                                </div>

                                <div class="col-md-4">
                                <div class="form-group">
                                  <label class="text-dark" for="">Max Qty :</label>
                                  <input value="{{ old('max_order_qty') }}" min="1" type="number" class="form-control" name="max_order_qty" placeholder="Enter Max Qty For order">
                                </div>
                                </div>

                              </div>
                            <!-- === adminstatic form end ===========-->
                        </div>
                        <!-- === adminstatic end ======== -->

                        <!-- === flashmsg start ======== -->
                        <div class="tab-pane fade" id="linkedin" role="tabpanel" aria-labelledby="profile-tab">
                            <!-- === flashmsg form start ======== -->
                           
                            <br>
                              <div class="alert alert-warning">
                                  <p><i class="fa fa-info-circle" aria-hidden="true"></i> Important</p>

                                  <ul>
                                      <li>Altleast two variant image is required !</li>
                                      <li>Default image will be <b><i>Image 1</i></b> later you can change default image in edit variant section</li>
                                  </ul>
                              </div>	

                              <div class="row">

                                    <div class="col-md-4">
                                    <div class="form-group">
                                        <label class="text-dark">{{ __('Select Image 1') }}</label><br>
                                        <div class="input-group mb-3">
                                          <div class="input-group-prepend">
                                              <span class="input-group-text" id="inputGroupFileAddon01">Upload</span>
                                          </div>
                                          <div class="custom-file">
                                              <input type="file" class="custom-file-input" name="image1" id="inputGroupFile01" aria-describedby="inputGroupFileAddon01" required>
                                              <label class="custom-file-label" for="inputGroupFile01">Choose file</label>
                                          </div>
                                        </div>
                                    </div>
                                    </div>

                                    <div class="col-md-4">
                                    <div class="form-group">
                                        <label class="text-dark">{{ __('Select Image 2') }}</label><br>
                                        <div class="input-group mb-3">
                                          <div class="input-group-prepend">
                                              <span class="input-group-text" id="inputGroupFileAddon01">Upload</span>
                                          </div>
                                          <div class="custom-file">
                                              <input type="file" class="custom-file-input" name="image2" id="inputGroupFile01" aria-describedby="inputGroupFileAddon01" required>
                                              <label class="custom-file-label" for="inputGroupFile01">Choose file</label>
                                          </div>
                                        </div>
                                    </div>
                                    </div>

                                    <div class="col-md-4">
                                    <div class="form-group">
                                        <label class="text-dark">{{ __('Select Image 3') }}</label><br>
                                        <div class="input-group mb-3">
                                          <div class="input-group-prepend">
                                              <span class="input-group-text" id="inputGroupFileAddon01">Upload</span>
                                          </div>
                                          <div class="custom-file">
                                              <input type="file" class="custom-file-input" name="image3" id="inputGroupFile01" aria-describedby="inputGroupFileAddon01" required>
                                              <label class="custom-file-label" for="inputGroupFile01">Choose file</label>
                                          </div>
                                        </div>
                                    </div>
                                    </div>

                                    <div class="col-md-4">
                                    <div class="form-group">
                                        <label class="text-dark">{{ __('Select Image 4') }}</label><br>
                                        <div class="input-group mb-3">
                                          <div class="input-group-prepend">
                                              <span class="input-group-text" id="inputGroupFileAddon01">Upload</span>
                                          </div>
                                          <div class="custom-file">
                                              <input type="file" class="custom-file-input" name="image4" id="inputGroupFile01" aria-describedby="inputGroupFileAddon01" required>
                                              <label class="custom-file-label" for="inputGroupFile01">Choose file</label>
                                          </div>
                                        </div>
                                    </div>
                                    </div>

                                    <div class="col-md-4">
                                    <div class="form-group">
                                        <label class="text-dark">{{ __('Select Image 5') }}</label><br>
                                        <div class="input-group mb-3">
                                          <div class="input-group-prepend">
                                              <span class="input-group-text" id="inputGroupFileAddon01">Upload</span>
                                          </div>
                                          <div class="custom-file">
                                              <input type="file" class="custom-file-input" name="image5" id="inputGroupFile01" aria-describedby="inputGroupFileAddon01" required>
                                              <label class="custom-file-label" for="inputGroupFile01">Choose file</label>
                                          </div>
                                        </div>
                                    </div>
                                    </div>

                                    <div class="col-md-4">
                                    <div class="form-group">
                                        <label class="text-dark">{{ __('Select Image 6') }}</label><br>
                                        <div class="input-group mb-3">
                                          <div class="input-group-prepend">
                                              <span class="input-group-text" id="inputGroupFileAddon01">Upload</span>
                                          </div>
                                          <div class="custom-file">
                                              <input type="file" class="custom-file-input" name="image6" id="inputGroupFile01" aria-describedby="inputGroupFileAddon01" required>
                                              <label class="custom-file-label" for="inputGroupFile01">Choose file</label>
                                          </div>
                                        </div>
                                    </div>
                                    </div>

                              </div>
                          </div>

                        </div>
   
                      <div class="col-md-12">
                        <button @if(env('DEMO_LOCK') == 0) type="submit" @else disabled="" title="This action is disabled in demo !" @endif class="pull-right btn btn-md btn-primary"><i class="feather icon-plus mr-2"></i> Add Stock</button>
                      </div>
        
  
                      </form>
                      </div>

                      </div>
                      </div>
                            <!-- === flashmsg form end ===========-->
                        </div>
                        <!-- === flashmsg end ======== -->

                    </div>
                </div><!-- card body end -->
            
        </div><!-- col end -->
    </div>
</div>
</div><!-- row end -->
    <br><br>
@endsection
@section('custom-script')
	<script src="{{ url('js/subvar.js') }}"></script>
@endsection