@extends('admin.layouts.master-soyuz')
@section('title','Edit Product Variant | ')
@section('body')
@component('admin.component.breadcumb',['thirdactive' => 'active'])
@slot('heading')
{{ __('Edit Product Variant') }}
@endslot
@slot('menu2')
{{ __("Edit Product Variant") }}
@endslot

@slot('button')
<div class="col-md-6">
  <div class="widgetbar">
  <a href="{{ route('add.var',$vars->products->id) }}" class="btn btn-primary-rgba"><i class="feather icon-arrow-left mr-2"></i>{{ __("Back")}}</a>
  </div>
</div>
@endslot

@endcomponent
<div class="contentbar">
    <div class="row">
@if ($errors->any())  
  <div class="alert alert-danger" role="alert">
  @foreach($errors->all() as $error)     
  <p>{{ $error}}<button type="button" class="close" data-dismiss="alert" aria-label="Close">
  <span aria-hidden="true" style="color:red;">&times;</span></button></p>
      @endforeach  
  </div>
  @endif
  
    <!-- row started -->
    <div class="col-lg-12">
    
        <div class="card m-b-30">
                <!-- Card header will display you the heading -->
                <div class="card-header">
                    <h5 class="card-box"> Edit Product Variant For <b>{{ $vars->products->name }}</b></h5>
                </div> 
               
                <!-- card body started -->
                <div class="card-body">
                <ul class="nav nav-tabs mb-3" id="defaultTab" role="tablist">
                        <li class="nav-item">
                            <a class="nav-link active" id="home-tab" data-toggle="tab" href="#facebook" role="tab" aria-controls="home" aria-selected="true">{{ __('Edit Variant') }}</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" id="profile-tab" data-toggle="tab" href="#google" role="tab" aria-controls="profile" aria-selected="false">{{ __('Pricing & Weight') }}</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" id="profile-tab" data-toggle="tab" href="#twitter" role="tab" aria-controls="profile" aria-selected="false">{{ __('Manage Stock') }}</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" id="profile-tab" data-toggle="tab" href="#linkedin" role="tab" aria-controls="profile" aria-selected="false">{{ __('Edit Images') }}</a>
                        </li>
                    </ul>
                    <div class="tab-content" id="defaultTabContent">

                        <!-- === language start ======== -->
                        <div class="tab-pane fade show active" id="facebook" role="tabpanel" aria-labelledby="home-tab">
                            <!-- === language form start ======== -->
                            <p>1</p>
                            <!-- === language form end ===========-->    
                        </div>
                          <!-- === language end ======== -->

                          <!-- === frontstatic start ======== -->
                        <div class="tab-pane fade" id="google" role="tabpanel" aria-labelledby="profile-tab">
                            <!-- === frontstatic form start ======== -->

                            <div class="row">

                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label class="text-dark" for="">Edit Additional Price For This Variant :</label>
                                        <input required value="{{ old('price') }}" placeholder="Enter Price ex 499.99" type="number" value="{{ $vars->price }}" step=0.01 class="form-control" name="price">
                                        <small class="help-block">Please enter Price In Positive or Negative or zero<br></small>
                                        <!-- ------------------------------------ -->
                                        <div class="card bg-success-rgba m-b-30">
                                          <div class="card-body">
                                            <div class="row align-items-center">
                                              <div class="col-12">
                                                <h5 class="card-title text-primary mb-1"><i class="feather icon-alert-circle"></i> {{ __('Ex. :') }}</h5>
                                                <p class="mb-0 text-primary font-14"><b>Ex. </b>If you enter +10 and product price is 100 than price will be 110<br> OR <br>If you enter -10 and product price is 100 than price will be 90</p>
                                              </div>
                                            </div>
                                          </div>
                                        </div>
                                        <!--------------------------------------  -->
                                      </div>
                                </div>

                                <div class="col-md-3">
                                <div class="form-group">
                                    <label class="text-dark" for="weight">Weight:</label>
                                    <input type="number" step=0.01 name="weight" class="form-control" value="{{ $vars->weight }}" placeholder="0.00">
                                </div>
                                </div>

                                <div class="col-md-3">
                                <div class="form-group">
                                    <label class="text-dark" for="weight"></label>
                                    <select name="w_unit" class="select2 form-control">
                                            <option value="">Please Choose</option>
                                            @php
                                                $unit = App\Unit::find(1);
                                            @endphp
                                            @if(isset($unit))
                                            @foreach($unit->unitvalues as $unitVal)
                                            <option {{ $vars->w_unit == $unitVal->id ? "selected"  :"" }}
                                                value="{{ $unitVal->id }}">{{ ucfirst($unitVal->short_code) }}
                                                ({{ $unitVal->unit_values }})</option>
                                            @endforeach
                                            @endif
                                        </select>
                                </div>
                                </div>

                            </div>

                            <!-- === frontstatic form end ===========-->
                        </div>
                        <!-- === frontstatic end ======== -->

                        <!-- === adminstatic start ======== -->
                        <div class="tab-pane fade" id="twitter" role="tabpanel" aria-labelledby="profile-tab">
                            <!-- === adminstatic form start ======== -->
                            <br>
                            <div class="row">
                                <div class="col-md-4">
                                <div class="form-group">
                                  <label class="text-dark" for="">Edit Stock: <small><b>[ Current Stock: {{ $vars->stock }}</b>
                                        ]</small></label>
                                        <input data-placement="bottom" id="stock" data-toggle="popover" data-trigger="focus"
                                    data-title="Need help?"
                                    data-content="It will add stock in existing stock. For example you enter 10 and existing stock is 20 than total stock will be 30."
                                    type="text" value="" name="stock" class="form-control">
                                </div>
                                </div>

                                <div class="col-md-4">
                                <div class="form-group">
                                  <label class="text-dark" for="">Edit Min Order Qty:</label>
                                  <input type="text" value="{{ $vars->min_order_qty }}" name="min_order_qty"
                                    class="form-control">
                                </div>
                                </div>

                                <div class="col-md-4">
                                <div class="form-group">
                                  <label class="text-dark" for="">Edit Max Order Qty:</label>
                                  <input type="text" value="{{ $vars->max_order_qty }}" name="max_order_qty"
                                    class="form-control">
                                </div>
                                </div>

                              </div>
                            <!-- === adminstatic form end ===========-->
                        </div>
                        <!-- === adminstatic end ======== -->

                        <!-- === flashmsg start ======== -->
                        <div class="tab-pane fade" id="linkedin" role="tabpanel" aria-labelledby="profile-tab">
                            <!-- === flashmsg form start ======== -->
                           
                            <br>
                              <div class="alert alert-warning">
                                  <p><i class="fa fa-info-circle" aria-hidden="true"></i> Important</p>

                                  <ul>
                                      <li>Altleast two variant image is required !</li>
                                      <li>Default image will be <b><i>Image 1</i></b> later you can change default image in edit variant section</li>
                                  </ul>
                              </div>	

                              <div class="row">

                                    <div class="col-md-4">
                                    <div class="form-group">
                                        <label class="text-dark">{{ __('Select Image 1') }}</label><br>
                                        <div class="input-group mb-3">
                                          <div class="input-group-prepend">
                                              <span class="input-group-text" id="inputGroupFileAddon01">Upload</span>
                                          </div>
                                          <div class="custom-file">
                                              <input type="file" class="custom-file-input" name="image1" id="inputGroupFile01" aria-describedby="inputGroupFileAddon01" required>
                                              <label class="custom-file-label" for="inputGroupFile01">Choose file</label>
                                          </div>
                                        </div>
                                    </div>
                                    @if($vars->variantimages && $vars->variantimages['image1'])
                                    <img src="{{ url('variantimages/'.$vars->variantimages['image1']) }}" class="image_size"/>
                                    @endif
                                    </div>

                                    <div class="col-md-4">
                                    <div class="form-group">
                                        <label class="text-dark">{{ __('Select Image 2') }}</label><br>
                                        <div class="input-group mb-3">
                                          <div class="input-group-prepend">
                                              <span class="input-group-text" id="inputGroupFileAddon01">Upload</span>
                                          </div>
                                          <div class="custom-file">
                                              <input type="file" class="custom-file-input" name="image2" id="inputGroupFile01" aria-describedby="inputGroupFileAddon01" required>
                                              <label class="custom-file-label" for="inputGroupFile01">Choose file</label>
                                          </div>
                                        </div>
                                    </div>
                                    @if($vars->variantimages && $vars->variantimages['image2'])
                                    <img src="{{ url('variantimages/'.$vars->variantimages['image2']) }}" class="image_size"/>
                                    @endif
                                    </div>

                                    <div class="col-md-4">
                                    <div class="form-group">
                                        <label class="text-dark">{{ __('Select Image 3') }}</label><br>
                                        <div class="input-group mb-3">
                                          <div class="input-group-prepend">
                                              <span class="input-group-text" id="inputGroupFileAddon01">Upload</span>
                                          </div>
                                          <div class="custom-file">
                                              <input type="file" class="custom-file-input" name="image3" id="inputGroupFile01" aria-describedby="inputGroupFileAddon01" required>
                                              <label class="custom-file-label" for="inputGroupFile01">Choose file</label>
                                          </div>
                                        </div>
                                    </div>
                                    @if($vars->variantimages && $vars->variantimages['image3'])
                                    <img src="{{ url('variantimages/'.$vars->variantimages['image3']) }}" class="image_size"/>
                                    @endif
                                    </div>

                                    <div class="col-md-4">
                                    <div class="form-group">
                                        <label class="text-dark">{{ __('Select Image 4') }}</label><br>
                                        <div class="input-group mb-3">
                                          <div class="input-group-prepend">
                                              <span class="input-group-text" id="inputGroupFileAddon01">Upload</span>
                                          </div>
                                          <div class="custom-file">
                                              <input type="file" class="custom-file-input" name="image4" id="inputGroupFile01" aria-describedby="inputGroupFileAddon01" required>
                                              <label class="custom-file-label" for="inputGroupFile01">Choose file</label>
                                          </div>
                                        </div>
                                    </div>
                                    @if($vars->variantimages && $vars->variantimages['image4'])
                                    <img src="{{ url('variantimages/'.$vars->variantimages['image4']) }}" class="image_size"/>
                                    @endif
                                    </div>

                                    <div class="col-md-4">
                                    <div class="form-group">
                                        <label class="text-dark">{{ __('Select Image 5') }}</label><br>
                                        <div class="input-group mb-3">
                                          <div class="input-group-prepend">
                                              <span class="input-group-text" id="inputGroupFileAddon01">Upload</span>
                                          </div>
                                          <div class="custom-file">
                                              <input type="file" class="custom-file-input" name="image5" id="inputGroupFile01" aria-describedby="inputGroupFileAddon01" required>
                                              <label class="custom-file-label" for="inputGroupFile01">Choose file</label>
                                          </div>
                                        </div>
                                    </div>
                                    @if($vars->variantimages && $vars->variantimages['image5'])
                                    <img src="{{ url('variantimages/'.$vars->variantimages['image5']) }}" class="image_size"/>
                                    @endif
                                    </div>

                                    <div class="col-md-4">
                                    <div class="form-group">
                                        <label class="text-dark">{{ __('Select Image 6') }}</label><br>
                                        <div class="input-group mb-3">
                                          <div class="input-group-prepend">
                                              <span class="input-group-text" id="inputGroupFileAddon01">Upload</span>
                                          </div>
                                          <div class="custom-file">
                                              <input type="file" class="custom-file-input" name="image6" id="inputGroupFile01" aria-describedby="inputGroupFileAddon01" required>
                                              <label class="custom-file-label" for="inputGroupFile01">Choose file</label>
                                          </div>
                                        </div>
                                    </div>
                                    @if($vars->variantimages && $vars->variantimages['image6'])
                                    <img src="{{ url('variantimages/'.$vars->variantimages['image6']) }}" class="image_size"/>
                                    @endif
                                    </div>

                              </div>
                          </div>

                        </div>
   
                      <div class="col-md-12">
                        <button @if(env('DEMO_LOCK') == 0) type="submit" @else disabled="" title="This action is disabled in demo !" @endif class="pull-right btn btn-md btn-primary"><i class="feather icon-plus mr-2"></i> Add Stock</button>
                      </div>
        
  
                      </form>
                      </div>

                      </div>
                      </div>
                            <!-- === flashmsg form end ===========-->
                        </div>
                        <!-- === flashmsg end ======== -->

                    </div>
                </div><!-- card body end -->
            
        </div><!-- col end -->
    </div>
</div>
</div><!-- row end -->
    <br><br>
@endsection
@section('custom-script')
<script>
    var baseUrl = "<?= url('/') ?>";
</script>
<script src="{{ url('js/variant.js') }}"></script>
<script>
    var url = @json(url('/setdef/var/image/'.$vars->id));
</script>
<script src="{{url('js/variantimage.js')}}"></script>
<style>
    .image_size{
    height:80px;
    width:200px;
}
</style>
@endsection