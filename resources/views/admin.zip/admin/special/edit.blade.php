@extends('admin.layouts.master-soyuz')
@section('title','Edit  Special Offer |')
@section('body')
@component('admin.component.breadcumb',['thirdactive' => 'active'])
@slot('heading')
{{ __('Edit Special Offer') }}
@endslot
​
@slot('menu1')
{{ __("Special Offer") }}
@endslot
​
@slot('menu2')
{{ __("Edit Special Offer") }}
@endslot
@slot('button')
<div class="col-md-6">
  <div class="widgetbar">
  <a href="{{url('admin/special/')}}" class="btn btn-primary-rgba"><i class="feather icon-arrow-left mr-2"></i>{{ __("Back")}}</a>
  </div>
</div>
@endslot
@endcomponent
<div class="contentbar">
  <div class="row">
    @if ($errors->any())
    <div class="alert alert-danger" role="alert">
      @foreach($errors->all() as $error)
      <p>{{ $error}}<button type="button" class="close" data-dismiss="alert" aria-label="Close">
          <span aria-hidden="true" style="color:red;">&times;</span></button></p>
      @endforeach
    </div>
    @endif
​
​
    <div class="col-lg-12">
      <div class="card m-b-30">
        <div class="card-header">
          <h5>{{ __('Edit Special Offer') }}</h5>
        </div>
        <div class="card-body">
          
          <!-- form start -->
         <form action="{{url('admin/special/'.$products->id)}}" class="form" method="POST" novalidate enctype="multipart/form-data">
          {{csrf_field()}}
          {{ method_field('PUT') }}
                       
              <div class="row">
                
                <!-- Product name -->
                <div class="col-md-6">
                    <div class="form-group">
                        <label class="text-dark">{{ __('Product name') }} <span class="text-danger">*</span></label>
                          <select class="select2 form-control" name="pro_id">
                              <option value="0">Please Select Product</option>
                              @foreach($products_pro as $pro)
                              <option value="{{$pro->id}}" {{ $pro->id == $products->pro_id ? 'selected="selected"' : '' }}>{{$pro->name}}</option>
                              @endforeach
                          </select>
                        
                    </div>
                </div>

                  <!-- Status -->
                  <div class="form-group col-md-6">
                    <label for="exampleInputDetails">{{ __('Status') }} </label><br>
                    <label class="switch">
                      <input class="slider" type="checkbox" name="status" <?php echo ($products->status=='1')?'checked':'' ?> />
                      <span class="knob"></span>
                    </label><br>
                    <small>{{ __("(Please Choose Status)")}}</small>
                </div>
                              
                <!-- create and close button -->
                <div class="col-md-12">
                    <div class="form-group">
                        <button type="reset" class="btn btn-danger mr-1"><i class="fa fa-ban"></i> {{ __("Reset")}}</button>
                        <button type="submit" class="btn btn-primary"><i class="fa fa-check-circle"></i>
                        {{ __("Create")}}</button>
                    </div>
                </div>

              </div><!-- row end -->
                                              
            </form>
            <!-- form end -->
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
  @endsection