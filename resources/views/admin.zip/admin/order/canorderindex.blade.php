@extends('admin.layouts.master-soyuz')
@section('title','Canceled Orders |')
@section('body')
@component('admin.component.breadcumb',['thirdactive' => 'active'])
@slot('heading')
{{ __('Canceled Orders') }}
@endslot
@slot('menu2')
{{ __("Canceled Orders") }}
@endslot

@endcomponent
​
<div class="contentbar">
  <div class="row">
    @if ($errors->any())
    <div class="alert alert-danger" role="alert">
      @foreach($errors->all() as $error)
      <p>{{ $error}}<button type="button" class="close" data-dismiss="alert" aria-label="Close">
          <span aria-hidden="true" style="color:red;">&times;</span></button></p>
      @endforeach
    </div>
    @endif
    <div class="col-lg-12">
      <div class="card m-b-30">
        <div class="card-header">
          <h5 class="box-title">{{ __('Canceled Orders') }}</h5>
        </div>
        <div class="card-body ml-2">
                  <!-- main content start -->
                  <div class="card m-b-30">

				  	<!-- ------------------------------------ -->
					<div class="card bg-success-rgba m-b-30">
						<div class="card-body">
						<div class="row align-items-center">
							<div class="col-12">
							<h5 class="card-title text-primary mb-1"><i class="fa fa-info-circle"></i> {{ __('Note :') }}</h5>
							<p class="mb-0 text-primary font-14">{{ __('COD Orders are only viewable !') }}</p>
							<p class="mb-0 text-primary font-14">{{ __('For Prepaid canceled orders with refund method choosen Bank You can update order IF refund is complete.') }}</p>
							<p class="mb-0 text-primary font-14">{{ __('For Prepaid canceled orders with refund method choosen orignal you can track refund status LIVE from respective Payment gateway & Update TXN/REF ID.') }}</p>
							</div>
							
						</div>
						</div>
					</div>
					<!--------------------------------------  -->
    
                      <!-- card body started -->
                      <div class="card-body">

                            <ul class="nav nav-tabs mb-3" id="defaultTab" role="tablist">  
                                <li class="nav-item">
                                    <a class="nav-link" id="profile-tab" data-toggle="tab" href="#location" role="tab" aria-controls="profile" aria-selected="false">Single Canceled Orders  @if($partialcount>0)<span class="badge badge-danger"><span id="pcount">{{ $partialcount }}</span> New @endif</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" id="profile-tab" data-toggle="tab" href="#checkout" role="tab" aria-controls="profile" aria-selected="false">Bulk Canceled Orders @if($fullcount>0)<span class="badge badge-danger"><span id="fcount">{{ $fullcount }}</span> New @endif</a>
                                </li>
                            </ul>

                                <div class="tab-content" id="defaultTabContent">
									<!-- ===  Progessive Web App Requirements start ======== -->
									<div class="tab-pane fade show active" id="location" role="tabpanel" aria-labelledby="location-tab">
										<!-- ===  Progessive Web App Requirements form start ======== -->
										

									<div class="row">
										<!-- --------------- main content start ------------------- -->
										<table id="full_detail_table" class="width100 table table-responsive">
											<thead>

												<th>
													#
												</th>

												<th>
													Order TYPE
												</th>

												<th>
													ORDER ID
												</th>

												<th>
													REASON for Cancellation
												</th>

												<th>
													REFUND METHOD
												</th>

												<th>
													CUSTOMER
												</th>

												<th>
													REFUND STATUS
												</th>

											</thead>

											<tbody>
												@foreach($cOrders as $key=> $order)
													<tr>
														<td>{{ $key+1 }}</td>
														<td>

															@if($order->order->payment_method != 'COD')
																<label class="label label-success">PREPAID</label>
															@else
																<label class="label label-primary">COD</label>
															@endif

														</td>
														<td>
															@if($order->read_at == NULL)
																<b>#{{ $inv_cus->order_prefix.$order->order->order_id }}</b>
															@else
																#{{ $inv_cus->order_prefix.$order->order->order_id }}
															@endif
															<br>
															<small class="text-center">
																@if($order->method_choosen == 'bank' || $order->order->payment_method == 'COD')
																	<a onclick="readorder('{{ $order->id }}')" title="UPDATE Order" class="cpointer" data-toggle="modal" data-target="#orderupdate{{ $order->id }}">UPDATE ORDER</a>
																@else

																	<a class="cpointer" onclick="readorder('{{ $order->id }}')" title="UPDATE Order" data-toggle="modal" data-target="#orderupdate{{ $order->id }}">UPDATE ORDER</a> | <a onclick="trackrefund('{{ $order->id }}')" class="cpointer" title="Track REFUND">TRACK REFUND</a>
																@endif
															</small>
														</td>
														<td>
															{{ $order->comment }}
														</td>
														<td>
															@if($order->method_choosen == 'bank')
																{{ ucfirst($order->method_choosen) }}
															@elseif($order->method_choosen == 'orignal')
																{{ ucfirst($order->method_choosen) }} ({{ ucfirst($order->order->payment_method) }})
															@else
															No need for COD Orders
															@endif
														</td>
														<td>
															@php
																$name = App\User::find($order->order->user_id)->name;
															@endphp

															@if(isset($name))
															{{ $name }}
															@else

															No Name

															@endif
														</td>

														<td>
															@if($order->is_refunded == 'pending')
																<label class="label label-primary">{{ ucfirst($order->is_refunded) }}</label>
															@else
																<label class="label label-success">{{ ucfirst($order->is_refunded) }}</label>
															@endif
														</td>

														<!--trackmodel-->



													</tr>
												@endforeach
											</tbody>
										</table>
										<!-- --------------- main content end --------------- -->
									</div>
										<!-- === Progessive Web App Requirements form end ===========-->
									</div>
									<!-- === Progessive Web App Requirements end ======== -->

									<!-- === PWA Icons & Splash screens start ======== -->
									<div class="tab-pane fade" id="checkout" role="tabpanel" aria-labelledby="checkout-tab">
									<!-- === PWA Icons & Splash screens form start ======== -->
									
									<hr>

									<table id="full_detail_table2" class="width100 table table-striped">
										<thead>
											<th>
												#
											</th>
											<th>
												Order TYPE
											</th>
											<th>
												Order ID
											</th>
											<th>
												REASON for Cancellation
											</th>
											<th>
												REFUND METHOD
											</th>
											<th>
												CUSTOMER
											</th>
											<th>
												REFUND STATUS
											</th>
										</thead>

										<tbody>
											@foreach($comOrder as $key=> $fcorder)
												<tr>
													<td>{{ $key+1 }}</td>
													<td>

															@if($fcorder->getorderinfo->payment_method != 'COD')
																<label class="label label-success">PREPAID</label>
															@else
																<label class="label label-primary">COD</label>
															@endif
													</td>
													<td>
														@if($fcorder->read_at == NULL)
														<b>#{{ $inv_cus->order_prefix.$fcorder->getorderinfo->order_id }}</b>
														@else
															#{{ $inv_cus->order_prefix.$fcorder->getorderinfo->order_id }}
														@endif
														<br>
															<small class="text-center">
																@if($fcorder->method_choosen == 'bank' || $fcorder->getorderinfo->payment_method == 'COD')
																	<a onclick="readfullorder('{{ $fcorder->id }}')" title="UPDATE Order" class="cpointer" data-toggle="modal" data-target="#fullorderupdate{{ $fcorder->id }}">UPDATE ORDER</a>
																@else
																	<a onclick="readfullorder('{{ $fcorder->id }}')" title="UPDATE Order" class="cpointer" data-toggle="modal" data-target="#fullorderupdate{{ $fcorder->id }}">UPDATE ORDER</a> | <a class="cpointer" title="Track REFUND" onclick="trackrefundFullCOrder('{{ $fcorder->id }}')">TRACK REFUND</a>
																@endif
															</small>
													</td>
													<td>
														{{ $fcorder->comment }}
													</td>
													<td>
															@if($fcorder->method_choosen == 'bank')
																{{ ucfirst($fcorder->method_choosen) }}
															@elseif($fcorder->method_choosen == 'orignal')
																{{ ucfirst($fcorder->method_choosen) }} ({{ ucfirst($fcorder->getorderinfo->payment_method) }})
															@else
															No need for COD Orders
															@endif
													</td>
													<td>
														{{ $fcorder->user->name }}
													</td>

													<td>
															@if($fcorder->is_refunded == 'pending')
																<label class="label label-primary">{{ ucfirst($fcorder->is_refunded) }}</label>
															@else
																<label class="label label-success">{{ ucfirst($fcorder->is_refunded) }}</label>
															@endif
													</td>


													<!-- END Full Order Update Modal -->
												</tr>
											@endforeach
										</tbody>
									</table>
									<!-- === PWA Icons & Splash screens form end ===========-->
									</div>
									<!-- === PWA Icons & Splash screens end ======== -->

                          </div>
                            </div><!-- card body end -->
                        
                      </div><!-- col end -->
                  </div>
                  <!-- main content end -->
        </div>
      </div>
    </div>
  </div>
</div>

<!-- Single Refund Modal -->
@include('admin.order.singleordermodal')
<!--END-->

<!-- FULL Refund Modal -->
@include('admin.order.fullordermodal')
<!--END-->
@endsection
@section('custom-script')
    <script>var baseUrl = "<?= url('/') ?>";</script>
	<script src="{{ url('js/order.js') }}"></script>
@endsection