@extends('admin.layouts.master-soyuz')
@section('title','Invoice Setting |')
@section('body')
​
@component('admin.component.breadcumb',['thirdactive' => 'active'])
​
@slot('heading')
{{ __('Retured Orders') }}
@endslot
​
@slot('menu2')
{{ __("Retured Orders") }}
@endslot
​
@endcomponent
<div class="contentbar">
    <div class="row">
@if ($errors->any())  
  <div class="alert alert-danger" role="alert">
  @foreach($errors->all() as $error)     
  <p>{{ $error}}<button type="button" class="close" data-dismiss="alert" aria-label="Close">
  <span aria-hidden="true" style="color:red;">&times;</span></button></p>
      @endforeach  
  </div>
  @endif
  
    <!-- row started -->
    <div class="col-lg-12">
    
        <div class="card m-b-30">
       
                <!-- Card header will display you the heading -->
                <div class="card-header">
                    <h5 class="card-box">{{ __('Retured Orders') }}</h5>
                </div> 
               
                <!-- card body started -->
                <div class="card-body">
                <ul class="nav nav-tabs mb-3" id="defaultTab" role="tablist">
                        <li class="nav-item">
                            <a class="nav-link active" id="home-tab" data-toggle="tab" href="#facebook" role="tab" aria-controls="home" aria-selected="true">Return Completed @if($countC>0) <span class="badge">{{$countC}}</span> @endif</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" id="profile-tab" data-toggle="tab" href="#google" role="tab" aria-controls="profile" aria-selected="false">Pending Returns @if($countP>0) <span class="badge">{{$countP}}</span>@endif</a>
                        </li>
                      
                    </ul>
                    <div class="tab-content" id="defaultTabContent">

                        <!-- === Return Completed start ======== -->
                        <div class="tab-pane fade show active" id="facebook" role="tabpanel" aria-labelledby="home-tab">
                            <!-- === Return Completed table start ======== -->
							<div class="row">
        <div class="col-md-12">
            <!-- card started -->
            <div class="card">
                <!-- card body started -->
                <div class="card-body">
                <div class="table-responsive">

                        <!-- table to display language start -->
                        <table id="full_detail_table2" class="table table-striped table-bordered">
                        <thead>
                           
							<th>
								#
							</th>
							<th>
								Order ID
							</th>
							<th>
								Item
							</th>
							<th>
								Refunded Amount
							</th>
							<th>
								Refund Status
							</th>

                        </thead>
                        
                        <tbody>

						@foreach($orders as $key=> $order)
									
									@if(isset($order->getorder->order) && $order->status != 'initiated')
									<tr>
										<td>
											{{ $key+1 }}
										</td>
										<td><b>#{{ $inv_cus->order_prefix.$order->getorder->order->order_id }}</b>
												<br>
												<small>
													<a title="View Refund Detail" href="{{  route('return.order.detail',$order->id)  }}">View Detail</a> 
												</small>
										</td>
										<td>
											@php
												$findvar = App\AddSubVariant::withTrashed()->find($order->getorder->variant_id);


												$varcount = count($findvar->main_attr_value);
												$i=0;
				                      			$var_name_count = count($findvar['main_attr_id']);
			                      				unset($name);
						                      	$name = array();
						                      	$var_name;

					                            $newarr = array();
					                            for($i = 0; $i<$var_name_count; $i++){
					                              $var_id =$findvar['main_attr_id'][$i];
					                              $var_name[$i] = $findvar['main_attr_value'][$var_id];
					                               
					                                $name[$i] = App\ProductAttributes::where('id',$var_id)->first();
					                                
					                            }


					                          try{
					                            $url = url(url('details').'/').'/'.$findvar->products->id.'?'.$name[0]['attr_name'].'='.$var_name[0].'&'.$name[1]['attr_name'].'='.$var_name[1];
					                          }catch(Exception $e)
					                          {
					                            $url = url(url('details').'/').'/'.$findvar->products->id.'?'.$name[0]['attr_name'].'='.$var_name[0];
					                          }

			                  				@endphp

											<b><a target="_blank" title="{{ $findvar->products->name }} (@php
											
					 
											 $varcount = count($findvar->main_attr_value);
								    		 $var_main;
								    		 $i=0;
								    		//var code
							          		foreach ($findvar->main_attr_value as $key => $orivars) {

									              $i++;

									              $getattrname = App\ProductAttributes::where('id', $key)->first()->attr_name;
									              $getvarvalue = App\ProductValues::where('id', $orivars)->first();

									              if ($i < $varcount) {
									                if (strcasecmp($getvarvalue->unit_value, $getvarvalue->values) != 0 && $getvarvalue->unit_value != null) {
									                  if ($getvarvalue->proattr->attr_name == "Color" || $getvarvalue->proattr->attr_name == "Colour" || $getvarvalue->proattr->attr_name == "color" || $getvarvalue->proattr->attr_name == "colour") {

									                    echo $getvarvalue->values;

									                  } else {
									                    echo $getvarvalue->values . $getvarvalue->unit_value.',';
									                  }
									                } else {
									                  echo $getvarvalue->values;
									                }

									              } else {

									                if (strcasecmp($getvarvalue->unit_value, $getvarvalue->values) != 0 && $getvarvalue->unit_value != null) {

									                  if ($getvarvalue->proattr->attr_name == "Color" || $getvarvalue->proattr->attr_name == "Colour" || $getvarvalue->proattr->attr_name == "color" || $getvarvalue->proattr->attr_name == "colour") {

									                    echo $getvarvalue->values;
									                  } else {
									                     echo $getvarvalue->values.$getvarvalue->unit_value;
									                  }

									                } else {
									                  echo $getvarvalue->values;
									                }

									              }
									            } 
								            @endphp)" href="{{ $url }}">{{substr($findvar->products->name, 0, 25)}}{{strlen($findvar->products->name)>25 ? '...' : ""}}
											(

											@php
											
					 
											 $varcount = count($findvar->main_attr_value);
								    		 $var_main;
								    		 $i=0;
								    		//var code
							          		foreach ($findvar->main_attr_value as $key => $orivars) {

									              $i++;

									              $getattrname = App\ProductAttributes::where('id', $key)->first()->attr_name;
									              $getvarvalue = App\ProductValues::where('id', $orivars)->first();

									              if ($i < $varcount) {
									                if (strcasecmp($getvarvalue->unit_value, $getvarvalue->values) != 0 && $getvarvalue->unit_value != null) {
									                  if ($getvarvalue->proattr->attr_name == "Color" || $getvarvalue->proattr->attr_name == "Colour" || $getvarvalue->proattr->attr_name == "color" || $getvarvalue->proattr->attr_name == "colour") {

									                    echo $getvarvalue->values;

									                  } else {
									                    echo $getvarvalue->values . $getvarvalue->unit_value.',';
									                  }
									                } else {
									                  echo $getvarvalue->values;
									                }

									              } else {

									                if (strcasecmp($getvarvalue->unit_value, $getvarvalue->values) != 0 && $getvarvalue->unit_value != null) {

									                  if ($getvarvalue->proattr->attr_name == "Color" || $getvarvalue->proattr->attr_name == "Colour" || $getvarvalue->proattr->attr_name == "color" || $getvarvalue->proattr->attr_name == "colour") {

									                    echo $getvarvalue->values;
									                  } else {
									                     echo $getvarvalue->values.$getvarvalue->unit_value;
									                  }

									                } else {
									                  echo $getvarvalue->values;
									                }

									              }
									            } 
								            @endphp)</a></b>	
										</td>
										<td>
											<i class="{{ $order->getorder->order->paid_in }}"></i>{{ $order->amount }}
										</td>
										<td>
											<label class="label label-success">
												{{ ucfirst($order->status) }}
											</label>
										</td>
									</tr>
									@endif
										
									
								@endforeach
                         
                        </tbody>
                       
                        </table>                  
                        <!-- table to display language data end -->                
                    </div><!-- table-responsive div end -->
                </div><!-- card body end -->
            </div><!-- card end -->
        </div><!-- col end -->
    </div><!-- row end -->
                            <!-- === Return Completed table end ===========-->    
                        </div>
                          <!-- === Return Completed end ======== -->

                          <!-- === Pending Returns start ======== -->
                        <div class="tab-pane fade" id="google" role="tabpanel" aria-labelledby="profile-tab">
                            <!-- === Pending Returns table start ======== -->
                            <div class="row">
        <div class="col-md-12">
            <!-- card started -->
            <div class="card">
                <!-- card body started -->
                <div class="card-body">
                <div class="table-responsive">

                        <!-- table to display language start -->
                        <table id="full_detail_table" class="table table-striped table-bordered">
                        <thead>
							<th>
								#
							</th>
							<th>
								Order TYPE
							</th>
							<th>
								OrderID
							</th>
							<th>
								Pending Amount
							</th>
							<th>
								Requested By
							</th>
							<th>
								Requested on
							</th>
                        </thead>
                        
                        <tbody>
						@foreach($orders as $key=> $order)
									@if(isset($order->getorder->order) && $order->status == 'initiated')
										<tr>
											<td>{{ $key+1 }}</td>
											<td>
												@if($order->getorder->order->payment_method != 'COD')
													<label for="" class="badge badge-pill badge-success">
														PREPAID
													</label>
												@else
													<label for="" class="badge badge-pill badge-primary">
														COD
													</label>
												@endif
											</td>
											<td><b>#{{ $inv_cus->order_prefix.$order->getorder->order->order_id }}</b>
												<br>
												<small>
													<a href="{{ route('return.order.show',$order->id) }}">UPDATE ORDER</a>
												</small>
											</td>
											<td>
												<i class="{{ $order->getorder->order->paid_in }}"></i>{{ $order->amount }}
											</td>
											<td>
												{{ $order->user->name }}
											</td>
											<td>
												{{date('d-M-Y @ h:i A',strtotime($order->created_at))}}
											</td>
											
										</tr>
									@endif
								@endforeach
                        </tbody>
                       
                        </table>                  
                        <!-- table to display language data end -->                
                    </div><!-- table-responsive div end -->
                </div><!-- card body end -->
            </div><!-- card end -->
        </div><!-- col end -->
    </div><!-- row end -->
                            <!-- === Pending Returns table end ===========-->
                        </div>
                        <!-- === Pending Returns end ======== -->

                    </div>
                </div><!-- card body end -->
            
        </div><!-- col end -->
    </div>
</div>
</div><!-- row end -->
    <br><br>
@endsection
<!-- main content section ended -->
@section('custom-script')
    <script>var baseUrl = "<?= url('/') ?>";</script>
	<script src="{{ url('js/order.js') }}"></script>
@endsection