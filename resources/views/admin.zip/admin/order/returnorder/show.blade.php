@extends('admin.layouts.master-soyuz')
@section('title','Show Return Order #$inv_cus->order_prefix$orderid |')
@section('body')
​
@component('admin.component.breadcumb',['thirdactive' => 'active'])
​
@slot('heading')
{{ __('Refund Order Summary') }}
@endslot
​
@slot('menu2')
{{ __("Refund Order") }}
@endslot
@slot('button')
<div class="col-md-6">
  <div class="widgetbar">
  <a href="{{ route('return.order.index') }}" class="btn btn-primary-rgba"><i class="feather icon-arrow-left mr-2"></i>{{ __("Back")}}</a>
  </div>
</div>
@endslot
@endcomponent
<div class="contentbar">
    <div class="row">
@if ($errors->any())  
  <div class="alert alert-danger" role="alert">
  @foreach($errors->all() as $error)     
  <p>{{ $error}}<button type="button" class="close" data-dismiss="alert" aria-label="Close">
  <span aria-hidden="true" style="color:red;">&times;</span></button></p>
      @endforeach  
  </div>
  @endif
  
    <!-- row started -->
    <div class="col-lg-12">
    
        <div class="card m-b-30">
                <!-- Card header will display you the heading -->
                <div class="card-header">
                    <h5 class="card-box">Invoice No. {{ $inv_cus->prefix }}{{ $rorder->getorder->inv_no }}{{ $inv_cus->postfix }} | Order ID: {{ $inv_cus->order_prefix.$orderid }}</h5>
                </div> 
               
                <!-- card body started -->
                <div class="card-body">

                 <!-- table start -->
				 <table class="table table-striped">
				<thead>
					<th>
						Item
					</th>
					<th>
						Qty
					</th>
					<th>
						Status
					</th>
					<th>
						Refund Total
					</th>
					<th>
						REF.No/Transcation ID
					</th>
				</thead>

				<tbody>
					<tr>
						<td>

							<div class="row">
								<div class="col-md-3">
									@if($findvar->variantimages)
										<img class="img-responsive img-circle" src="{{url('variantimages/'.$findvar->variantimages['main_image'])}}"/>
									@else
										<img class="img-responsive img-circle" src="{{ Avatar::create($findvar->products->name) }}"/>
									@endif
								</div>

								<div class="col-md-9">
									<b>{{ $findvar->products->name }}
								(

							@php
							
			 
							 $varcount = count($findvar->main_attr_value);
				    		 $var_main;
				    		 $i=0;
				    		//var code
					          foreach ($findvar->main_attr_value as $key => $orivars) {

					              $i++;

					              $getattrname = App\ProductAttributes::where('id', $key)->first()->attr_name;
					              $getvarvalue = App\ProductValues::where('id', $orivars)->first();

					              if ($i < $varcount) {
					                if (strcasecmp($getvarvalue->unit_value, $getvarvalue->values) != 0 && $getvarvalue->unit_value != null) {
					                  if ($getvarvalue->proattr->attr_name == "Color" || $getvarvalue->proattr->attr_name == "Colour" || $getvarvalue->proattr->attr_name == "color" || $getvarvalue->proattr->attr_name == "colour") {

					                    echo $getvarvalue->values;

					                  } else {
					                    echo $getvarvalue->values . $getvarvalue->unit_value.',';
					                  }
					                } else {
					                  echo $getvarvalue->values;
					                }

					              } else {

					                if (strcasecmp($getvarvalue->unit_value, $getvarvalue->values) != 0 && $getvarvalue->unit_value != null) {

					                  if ($getvarvalue->proattr->attr_name == "Color" || $getvarvalue->proattr->attr_name == "Colour" || $getvarvalue->proattr->attr_name == "color" || $getvarvalue->proattr->attr_name == "colour") {

					                    echo $getvarvalue->values;
					                  } else {
					                     echo $getvarvalue->values.$getvarvalue->unit_value;
					                  }

					                } else {
					                  echo $getvarvalue->values;
					                }

					              }
					            } 
				            @endphp)</b>
				            <br>
				            <small><b>Sold By:</b> {{$findvar->products->store->name}}</small>
								</div>
							</div>
							
						</td>
						<td>
							{{ $rorder->qty }}
						</td>
						<td>
							<b>{{ ucfirst($rorder->status) }}</b> 
						</td>
						<td>
							<b><i class="{{ $rorder->getorder->order->paid_in }}"></i>{{ round($rorder->amount,2) }}</b>
						</td>
						<td>
							<b>{{ $rorder->txn_id }}</b>
						</td>
					</tr>
				</tbody>
			</table>
               
                  <!-- table end -->
				  <p></p>
			<div class="reason">
				<blockquote>
					Reason for Return: <span class="font-weight600">{{ $rorder->reason }}</span>
				</blockquote>
			</div>

			<p></p>
			<div class="reason">
				<blockquote>
					Refund Method Choosen: <span class="font-weight600">@if($rorder->method_choosen != 'bank') {{ ucfirst($rorder->method_choosen) }}({{ $rorder->getorder->order->payment_method }})  @else {{ ucfirst($rorder->method_choosen) }} @endif</span>
				</blockquote>
			</div>

			@if($rorder->method_choosen == 'orignal')
			<!-- ------------------------------------ -->
			<div class="card bg-success-rgba m-b-30">
				<div class="card-body">
					<div class="row align-items-center">
						<div class="col-8">
							<p class="mb-0 text-primary font-14"><i class="fa fa-info-circle"></i> Make Sure your {{ $rorder->getorder->order->payment_method }} account has sufficient balance before initiate refund !</p>
						</div>
						<div class="col-4 text-right">
							
						</div>
					</div>
				</div>
			</div>
			<!--------------------------------------  -->
			@endif

			<div class="row no-pad">
				@if($rorder->method_choosen == 'bank')
				<div class="text-center col-md-6">
					<div class="card card-1">
							<div class="user-header">
								<h4>User's Payment Details</h4>

							</div>
						<div class="bankdetail">
								
								<p><b>A/c Holder name: </b> {{ $rorder->bank->acname }}</p>
								<p><b>Bank Name: </b> {{ $rorder->bank->acname }}</p>
								<p><b>A/c No. </b> {{ $rorder->bank->acno }}</p>
								<p><b>IFSC Code: </b> {{ $rorder->bank->ifsc }}</p>
							</div>
						
						</div>
				
				</div>
				@endif

				<div class="card-body">
					<div class="order-primary-detail">
						<h6>Pickup Location</h6>
						<p class="mb-0">John Doe</p>
						<p class="mb-0">Sector -62 , RCM Area</p>
						<p class="mb-0">Bhilwara,Rajasthan,Bhilwara,</p>
						<p class="mb-0">311001</p>
					</div>
				</div>

				
				<!-- form start -->
				
                <form action="{{ route('final.process',$rorder->id) }}" class="form" method="POST" novalidate enctype="multipart/form-data">
				@csrf
                        <!-- row start -->
                        <div class="row">
                            <div class="col-md-12">
                                <!-- card start -->
                                <div class="card">
                                    <!-- card body start -->
                                    <div class="card-body">
                                        <!-- row start -->
                                          <div class="row">
                                              
                                              <div class="col-md-12">
                                                  <!-- row start -->
                                                  <div class="row">
                                                    
                                                    <!-- UPDATE AMOUNT -->
                                                    <div class="col-md-4">
                                                        <div class="form-group">
															<label class="text-dark">{{ __('UPDATE AMOUNT :') }}</label>
															<div class="input-group mb-3"><div class="input-group-prepend">
																	<span class="input-group-text">$</span>
																</div>
																<input type="text" name="amount" class="form-control" value="{{ round($rorder->amount,2) }}" aria-label="Amount (to the nearest dollar)">
																<input type="hidden" value="{{ round($rorder->amount,2) }}" id="actualAmount">
																<div class="input-group-append">
																	<span class="input-group-text">.00</span>
																</div>
																
															</div>
															<small class="help-block">(Amount will be updated if transcation fee charged)</small>
                                                        </div>
                                                    </div>

                                                    <!-- UPDATE Transaction ID: -->
                                                    <div class="col-md-4">
                                                        <div class="form-group">
                                                            <label class="text-dark">{{ __('Update Transaction ID :') }}<span class="text-danger">*</span></label>
															<input {{ $rorder->method_choosen == 'bank' ? "" : "readonly" }} type="text" class="form-control" value="{{ $rorder->txn_id }}" name="txn_id">
															<small class="help-block">(Use when, when bank transfer method is choosen)</small>
                                                        </div>
                                                    </div>

													<!-- UPDATE Transaction ID: -->
                                                    <div class="col-md-4">
                                                        <div class="form-group">
                                                            <label class="text-dark">{{ __('Update Transaction Fees :') }}<span class="text-danger">*</span></label>
															<input {{ $rorder->method_choosen == 'bank' ? "" : "readonly" }} placeholder="0.00" type="text" class="form-control" value="" name="txn_fee" id="txn_fee">
															<small class="help-block">(If charging during bank transfer (eg. in NEFT,IMPS,RTGS) Enter fee).</small>
                                                        </div>
                                                    </div>

                                                    <!-- UPDATE Transaction ID: -->
                                                    <div class="col-md-4">
                                                        <div class="form-group">
                                                            <label class="text-dark">{{ __('UPDATE Refund Status :') }}<span class="text-danger">*</span></label>
																<select name="status" class="form-control select2">
																	<option value="refunded">Refunded</option>
																</select>
                                                        </div>
                                                    </div>

													<!-- UPDATE Transaction ID: -->
                                                    <div class="col-md-4">
                                                        <div class="form-group">
                                                            <label class="text-dark">{{ __('UPDATE Order Status :') }}<span class="text-danger">*</span></label>
															<select name="order_status" class="form-control select2">
																<option value="ret_ref">Returned & Refunded</option>
																<option value="returned">Returned</option>
																<option value="refunded">Refunded</option>
															</select>
                                                        </div>
                                                    </div>
                                                                  
                                                    <!-- create and close button -->
                                                    <div class="col-md-12">
                                                        <div class="form-group">
														<button type="reset" class="btn btn-danger mr-1"><i class="fa fa-ban"></i> {{ __("Reset")}}</button>
															<button title="This action cannot be undone!" type="submit" class="btn btn-md btn-primary">
																<i class="fa fa-check-circle" aria-hidden="true"></i> Initiate Refund
															</button>
                                                        </div>
                                                    </div>

                                                  </div><!-- row end -->
                                              </div><!-- col end -->
                                          </div><!-- row end -->

                                    </div><!-- card body end -->
                                </div><!-- card end -->
                            </div><!-- col end -->
                        </div><!-- row end -->
                  </form>
				  
                  <!-- form end -->

				
				
			

                
                </div><!-- card body end -->
            
        </div><!-- col end -->
    </div>
</div>
</div><!-- row end -->
    <br><br>
	<!-- css for image start -->
<style>
.img-circle{
height:100px;
width:100px;
border-radius:50%;
}
</style>
<!-- css for image end -->
@endsection
<!-- main content section ended -->
<!-- This section will contain javacsript start -->
@section('script')
<script>var baseUrl = "<?= url('/') ?>";</script>
<script src="{{ url('js/order.js') }}"></script>
@endsection
<!-- This section will contain javacsript end -->