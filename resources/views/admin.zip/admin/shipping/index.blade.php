@extends('admin.layouts.master-soyuz')
@section('title','Shipping Settings |')
@section('body')
@component('admin.component.breadcumb',['thirdactive' => 'active'])
@slot('heading')
{{ __('Shipping') }}
@endslot
@slot('menu2')
{{ __("Shipping") }}
@endslot​
@endcomponent
<div class="contentbar">
  <div class="row">
    @if ($errors->any())
    <div class="alert alert-danger" role="alert">
      @foreach($errors->all() as $error)
      <p>{{ $error}}<button type="button" class="close" data-dismiss="alert" aria-label="Close">
          <span aria-hidden="true" style="color:red;">&times;</span></button></p>
      @endforeach
    </div>
    @endif
    <div class="col-lg-12">
      <div class="card m-b-30">
        <div class="card-header">
          <h5 >{{ __('Shipping') }}</h5>
        </div>
        <div class="card-body">
          <div class="table-responsive">
            <!-- table to display faq start -->
            <table id="datatable-buttons" class="table table-striped table-bordered">
              <thead>
                <th>{{ __('Default') }}</th>
                <th>{{ __('Shipping Title') }}</th>
                <th>{{ __('Price') }}</th>
                <th>{{ __('Status') }}</th>
                <th>{{ __('Action') }}</th>
                <th></th>
              </thead>
              <tbody>
                @foreach($shippings as $shipping)
                <tr>
                <td><input {{ $shipping->name == 'Local Pickup' || $shipping->name == 'UPS Shipping' ? "disabled" : ""}} type="radio" class="kk" id="{{$shipping->id}}" {{$shipping->default_status=='1'?'checked':''}} name="radio"></td>
                <td>{{$shipping->name}}</td>
                <td>{{$shipping->price ?? '---'}}</td>
                <td>
                  @if($shipping->login=='1')
                      {{'Yes'}}
                      @else
                      {{'No'}}
                    @endif
                  </td><td>
                  <a {{ $shipping->name == 'Free Shipping' || $shipping->name == 'UPS Shipping' ? "disabled" : ""}} href=" {{url('admin/shipping/'.$shipping->id.'/edit')}} " class="btn btn-primary btn-sm">
                  <i class="feather icon-edit-2"></i>
                  </a>
                </td>
                <td>
                  @php
                    $swt = App\ShippingWeight::first();
                  @endphp
                  @if($swt->value == $shipping->name)
                  <a href="{{ route('get.wt') }}" class="btn btn-sm btn-primary">Manage Weight</a>
                  @else
                  {{ "--" }}
                  @endif
                </td>
                </tr>
                @endforeach
              </tbody>
            </table>                  
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
         

@endsection
@section('custom-script')
  <script>var url = {!! json_encode( url('admin/shipping_update')) !!};</script>
  <script src="{{ url('js/ship.js') }}"></script>

@endsection
