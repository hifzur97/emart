@extends('admin.layouts.master-soyuz')
@section('title','Add New Product |')
@section('body')
​
@component('admin.component.breadcumb',['thirdactive' => 'active'])
​
@slot('heading')
{{ __('Add New Product') }}
@endslot
@slot('menu1')
{{ __("Product") }}
@endslot
@slot('menu2')
{{ __("Add New Product") }}
@endslot
​
@slot('button')
<div class="col-md-6">
  <div class="widgetbar">
  <a href="{{ route('products.index') }}" class="btn btn-primary-rgba"><i class="feather icon-arrow-left mr-2"></i>{{ __("Back")}}</a>
  </div>
</div>
@endslot
​
@endcomponent
<div class="contentbar">
  <div class="row">
    @if ($errors->any())
    <div class="alert alert-danger" role="alert">
      @foreach($errors->all() as $error)
      <p>{{ $error}}<button type="button" class="close" data-dismiss="alert" aria-label="Close">
          <span aria-hidden="true" style="color:red;">&times;</span></button></p>
      @endforeach
    </div>
    @endif
​
​
    <div class="col-lg-12">
      <div class="card m-b-30">
        <div class="card-header">
          <h5>{{ __('Add Product') }}</h5>
        </div>
        <div class="card-body">
            @include('admin.product.tab.product')
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
  @endsection