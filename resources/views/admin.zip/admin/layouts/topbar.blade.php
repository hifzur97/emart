 <!-- Start Topbar Mobile -->
 <div class="topbar-mobile">
     <div class="row align-items-center">
         <div class="col-md-12">
             <div class="mobile-logobar">
                 <a href="{{ url('/') }}" class="mobile-logo">

                     <img src="{{ url('images/genral/'.$genrals_settings->logo) }}" class="img-fluid" alt="logo" />

                 </a>
             </div>
             <div class="mobile-togglebar">
                 <ul class="list-inline mb-0">
                     <li class="list-inline-item">
                         <div class="topbar-toggle-icon">
                             <a class="topbar-toggle-hamburger" href="javascript:void();">
                                 <img src="{{ url('admin_new/assets/images/svg-icon/horizontal.svg') }}"
                                     class="img-fluid menu-hamburger-horizontal" alt="horizontal">
                                 <img src="{{ url('admin_new/assets/images/svg-icon/verticle.svg') }}"
                                     class="img-fluid menu-hamburger-vertical" alt="verticle">
                             </a>
                         </div>
                     </li>
                     <li class="list-inline-item">
                         <div class="menubar">
                             <a class="menu-hamburger" href="javascript:void();">
                                 <img src="{{ url('admin_new/assets/images/svg-icon/menu.svg') }}"
                                     class="img-fluid menu-hamburger-collapse" alt="collapse">
                                 <img src="{{ url('admin_new/assets/images/svg-icon/close.svg') }}"
                                     class="img-fluid menu-hamburger-close" alt="close">
                             </a>
                         </div>
                     </li>
                 </ul>
             </div>
         </div>
     </div>
 </div>
 <!-- Start Topbar -->
 <div class="topbar">
     <!-- Start row -->
     <div class="row align-items-center">
         <!-- Start col -->
         <div class="col-md-12 align-self-center">


             <div class="infobar">
                 <ul class="list-inline mb-0">

                    <li class="list-inline-item" id="stour">
                        <div class="settingbar "  >
                        <a class="cursor-pointer" onclick="starttour()">
                           {{__("Setup Tour")}} <i class="fa fa-plane fa-1x" aria-hidden="true"></i>
                        </a>
                      </div>
                      </li>

                    <li  class="list-inline-item">
                        <a title="Visit site" href="{{ url('/') }}" target="_blank">Visit Site 
                            <i class="fa fa-external-link" aria-hidden="true"></i>
                        </a>
                    </li>
                   
      
                    <li class="list-inline-item">
                        <div class="languagebar">
                            <div class="dropdown">
                               
                                    <select class="langdropdown2 form-control" onchange="changeLang()" id="changed_lng">
                                        @foreach(\DB::table('locales')->where('status','=',1)->get() as $lang)
                                        <option {{ Session::get('changed_language') == $lang->lang_code ? "selected" : ""}}
                                        value="{{ $lang->lang_code }}">{{ $lang->lang_code }}</option>
                                        @endforeach
                                    </select>
                                 
                                
                            </div>
                        </div>                                   
                    </li>

                    <li class="list-inline-item">
                        <div class="settingbar">
                            <a href="javascript:void(0)" id="infobar-settings-open" class="infobar-icon">
                                <img  src="{{ url('admin_new/assets/images/svg-icon/settings.svg') }}" class="img-fluid" alt="settings">
                                <span class="live-icon">3</span>
                            </a>
                        </div>
                    </li>


                     <li class="list-inline-item">
                         <div class="notifybar">
                             <div class="dropdown">
                                 <a class="dropdown-toggle infobar-icon" href="#" role="button" id="notoficationlink"
                                     data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><img
                                         src="{{ url('admin_new/assets/images/svg-icon/notifications.svg') }}" class="img-fluid"
                                         alt="notifications">
                                     <span class="live-icon">2</span></a>
                                 <div class="dropdown-menu dropdown-menu-right" aria-labelledby="notoficationlink">
                                     <div class="notification-dropdown-title">
                                         <h4>Notifications</h4>
                                     </div>
                                     <ul class="list-unstyled">

                                         <li class="media dropdown-item">
                                             <span class="mr-3 action-icon badge badge-warning-inverse">T</span>
                                             <div class="media-body">
                                                 <h5 class="action-title">This is start of your story</h5>
                                                 <p><span class="timing">Yesterday, 01:25 PM</span></p>
                                             </div>
                                         </li>

                                     </ul>
                                 </div>
                             </div>
                         </div>
                     </li>
                     <li class="list-inline-item">
                         <div class="profilebar">
                             <div class="dropdown">
                                 <a class="dropdown-toggle" href="#" role="button" id="profilelink"
                                     data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">

                                     @if(Auth::user()->image != '')
                                     <img src="{{url('images/user/'.Auth::user()->image)}}" alt="profilephoto"
                                         class="rounded img-fluid">
                                     @else
                                     <img src="{{ Avatar::create(Auth::user()->name)->toBase64() }}" alt="profilephoto"
                                         class="rounded img-fluid">
                                     @endif

                                     <span class="live-icon">{{ Auth::user()->name }}</span><span
                                         class="feather icon-chevron-down live-icon"></span></a>
                                 <div class="dropdown-menu dropdown-menu-right" aria-labelledby="profilelink">
                                     <div class="dropdown-item">
                                         <div class="profilename">
                                             <h5>{{ Auth::user()->name }}</h5>
                                         </div>
                                     </div>
                                     <div class="userbox">
                                         <ul class="list-unstyled mb-0">
                                             <li class="media dropdown-item">
                                                 @if(auth()->user()->role_id == 'v')
                                                    <a href="{{ route('get.profile') }}"
                                                        class="profile-icon"><img
                                                            src="{{ url('admin_new/assets/images/svg-icon/crm.svg') }}"
                                                        class="img-fluid" alt="user">{{ __("My Profile") }}
                                                    </a>
                                                @else

                                                    <a href="{{ url('admin/users/'.Auth::user()->id.'/edit') }}"
                                                    class="profile-icon"><img
                                                        src="{{ url('admin_new/assets/images/svg-icon/crm.svg') }}"
                                                        class="img-fluid" alt="user">{{ __("My Profile") }}
                                                    </a>
                                                
                                                @endif
                                             </li>
                                             @if(auth()->user()->role_id == 'v')
                                                <li class="media dropdown-item">
                                                    <a href="{{ route('store.index') }}"
                                                    class="profile-icon"><img
                                                        src="{{ url('admin_new/assets/images/svg-icon/ecommerce.svg') }}"
                                                        class="img-fluid" alt="user">{{ __("Your store") }}</a>
                                                </li>
                                            @else 
                                                <li class="media dropdown-item">
                                                    <a href="{{ url('admin/stores/'.Auth::user()->store->id.'/edit') }}"
                                                        class="profile-icon"><img
                                                            src="{{ url('admin_new/assets/images/svg-icon/ecommerce.svg') }}"
                                                            class="img-fluid" alt="user">{{ __("Your store") }}</a>
                                                </li>
                                            
                                            @endif

                                             <li class="media dropdown-item">
                                                 <a href="{{ route('logout') }}" class="profile-icon" onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();"><img
                                                         src="{{ url('admin_new/assets/images/svg-icon/logout.svg') }}"
                                                         class="img-fluid" alt="logout">Logout</a>

                                                 <form id="logout-form" action="{{ route('logout') }}" method="POST"
                                                     style="display: none;">
                                                     @csrf
                                                 </form>
                                             </li>
                                         </ul>
                                     </div>
                                 </div>
                             </div>
                         </div>
                     </li>
                 </ul>
             </div>
         </div>
         <!-- End col -->
     </div>
     <!-- End row -->
 </div>


 <div id="infobar-settings-sidebar" class="infobar-settings-sidebar">
    <div class="infobar-settings-sidebar-head d-flex w-100 justify-content-between">
        <h4>Settings</h4><a href="javascript:void(0)" id="infobar-settings-close" class="infobar-settings-close"><img  <img  src="{{ url('admin_new/assets/images/svg-icon/close.svg') }}" class="img-fluid menu-hamburger-close" alt="close"></a>
    </div>
    <div class="infobar-settings-sidebar-body">
        <div class="custom-mode-setting">
            <div class="row align-items-center pb-3">
                <div class="col-8"><h6 class="mb-0">New Order Notification</h6></div>
                <div class="col-4 text-right"><input type="checkbox" class="js-switch-setting-first" checked /></div>
            </div>
            <div class="row align-items-center pb-3">
                <div class="col-8"><h6 class="mb-0">Low Stock Alerts</h6></div>
                <div class="col-4 text-right"><input type="checkbox" class="js-switch-setting-second" checked /></div>
            </div>
            <div class="row align-items-center pb-3">
                <div class="col-8"><h6 class="mb-0">Vacation Mode</h6></div>
                <div class="col-4 text-right"><input type="checkbox" class="js-switch-setting-third" /></div>
            </div>
            <div class="row align-items-center pb-3">
                <div class="col-8"><h6 class="mb-0">Order Tracking</h6></div>
                <div class="col-4 text-right"><input type="checkbox" class="js-switch-setting-fourth" checked /></div>
            </div>
            <div class="row align-items-center pb-3">
                <div class="col-8"><h6 class="mb-0">Newsletter Subscription</h6></div>
                <div class="col-4 text-right"><input type="checkbox" class="js-switch-setting-fifth" checked /></div>
            </div>
            <div class="row align-items-center pb-3">
                <div class="col-8"><h6 class="mb-0">Show Review</h6></div>
                <div class="col-4 text-right"><input type="checkbox" class="js-switch-setting-sixth" /></div>
            </div>
            <div class="row align-items-center pb-3">
                <div class="col-8"><h6 class="mb-0">Enable Wallet</h6></div>
                <div class="col-4 text-right"><input type="checkbox" class="js-switch-setting-seventh" checked /></div>
            </div>
            <div class="row align-items-center">
                <div class="col-8"><h6 class="mb-0">Sales Report</h6></div>
                <div class="col-4 text-right"><input type="checkbox" class="js-switch-setting-eightth" checked /></div>
            </div>
        </div>
       
    </div>
</div>
