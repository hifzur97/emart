@extends("admin/layouts.master")
@section('title','Admin Dashboard | ')
@section("body")
<div class="breadcrumbbar">
  <div class="row align-items-center">
      <div class="col-md-8 col-lg-8">
         
          <div class="breadcrumb-list">
              <ol class="breadcrumb">
                  <h4><li class="breadcrumb-item text-dark">Dashboard</li></h4>
                  
              </ol>
          </div>
      </div>
      
  </div>          
</div>



<div class="contentbar">                
  <div class="row">
    <div class="col-lg-12 col-xl-12">
      <div class="row">
        <div class="col-md-3 ">
            <div class="card m-b-30 shadow-sm">
                <div class="card-body">
                  <div class="row">
                    <div class="col-8">
                      <h4>{{$user}}</h4>
                      <p class="font-14 mb-0 ">Total Users</p>
                    </div>
                    <div class="col-4 animate__animated animate__fadeIn animate__delay-2s">
                      <a href="{{route('users.index')}}"> <i class="text-success feather icon-user iconsize"></i>
                      </a>
                      </div>
                      
                  </div>
                </div>
            </div>
        </div>
     
        <div class="col-md-3 ">
            <div class="card m-b-30 shadow-sm">
                <div class="card-body">
                  <div class="row">
                    <div class="col-8">
                      <h4 >{{$order}}</h4>
                      <p class="font-14 mb-0">Total Orders</p>
                    </div>
                    <div class="col-4 animate__animated animate__fadeIn animate__delay-2s">
                      <a href="{{url('admin/order')}}"> <i class="text-warning feather icon-shopping-cart mr-2 iconsize"></i>
                      </a>
                      </div>
                      
                  </div>
                </div>
            </div>
        </div>

        <div class="col-md-3 ">
            <div class="card m-b-30 shadow-sm">
                <div class="card-body">
                  <div class="row">
                    <div class="col-8">
                      <h4>{{ $totalcancelorder }}</h4>
                      <p class="font-14 mb-0">Total Cancelled Orders</p>
                    </div>
                    <div class="col-4 animate__animated animate__fadeIn animate__delay-2s">
                      <a href="{{url('admin/ord/canceled')}}"> <i class="text-danger feather icon-x-circle iconsize"></i>
                      </a>
                      </div>
                      
                  </div>
                </div>
            </div>
        </div>

        <div class="col-md-3 ">
            <div class="card m-b-30 shadow-sm">
                <div class="card-body">
                  <div class="row">
                    <div class="col-8">
                      <h4>{{ $totalproducts }}</h4>
                      <p class="font-14 mb-0">Total Products</p>
                    </div>
                    <div class="col-4 animate__animated animate__fadeIn animate__delay-2s">
                      <a href="{{url('admin/products')}}"> <i class="text-primary feather icon-truck iconsize"></i>
                      </a>
                      </div>
                      
                  </div>
                </div>
            </div>
        </div>


        <div class="col-md-3 ">
            <div class="card m-b-30 shadow-sm">
                <div class="card-body">
                  <div class="row">
                    <div class="col-8">
                      <h4>{{$store}}</h4>
                      <p class="font-14 mb-0">Total Stores</p>
                    </div>
                    <div class="col-4 animate__animated animate__fadeIn animate__delay-2s">
                      <a href="{{url('admin/stores')}}"> <i class="text-info feather icon-home iconsize"></i>
                      </a>
                      </div>
                      
                  </div>
                </div>
            </div>
        </div>



        <div class="col-md-3 ">
            <div class="card m-b-30 shadow-sm">
                <div class="card-body">
                  <div class="row">
                    <div class="col-8">
                      <h4>{{$category}}</h4>
                      <p class="font-14 mb-0">Total Categories</p>
                    </div>
                    <div class="col-4 animate__animated animate__fadeIn animate__delay-2s">
                      <a  href="{{url('admin/category')}}"> <i class="text-secondary feather icon-shopping-bag iconsize"></i>
                      </a>
                      </div>
                      
                  </div>
                </div>
            </div>
        </div>


        <div class="col-md-3 ">
            <div class="card m-b-30 shadow-sm">
                <div class="card-body">
                  <div class="row">
                    <div class="col-8">
                      <h4>{{$coupan}}</h4>
                      <p class="font-14 mb-0">Total Coupons</p>
                    </div>
                    <div class="col-4 animate__animated animate__fadeIn animate__delay-2s">
                      <a href="{{url('admin/coupan')}}"> <i class="text-success feather icon-grid iconsize"></i>
                      </a>
                      </div>
                      
                  </div>
                </div>
            </div>
        </div>


        <div class="col-md-3 ">
            <div class="card m-b-30 shadow-sm">
                <div class="card-body">
                  <div class="row">
                    <div class="col-8">
                      <h4>{{$faqs}}</h4>
                      <p class="font-14 mb-0">Total FAQ's</p>
                    </div>
                    <div class="col-4 animate__animated animate__fadeIn animate__delay-2s">
                      <a href="{{url('admin/faq')}}"> <i class="text-warning feather icon-help-circle iconsize"></i>
                      </a>
                      </div>
                      
                  </div>
                </div>
            </div>
        </div>

        @if($genrals_settings->vendor_enable == 1)
        <div class="col-md-3 ">
            <div class="card m-b-30 shadow-sm">
                <div class="card-body">
                  <div class="row">
                    <div class="col-8">
                      <h4>{{ $pending_payout }}</h4>
                      <p class="font-14 mb-0">Pending Payouts</p>
                    </div>
                    <div class="col-4 animate__animated animate__fadeIn animate__delay-2s">
                      <a href="{{ route('seller.payouts.index') }}"> <i class="text-danger feather icon-credit-card iconsize"></i>
                      </a>
                      </div>
                      
                  </div>
                </div>
            </div>
        </div>
        <div class="col-md-3 ">
            <div class="card m-b-30 shadow-sm">
                <div class="card-body">
                  <div class="row">
                    <div class="col-8">
                      <h4>{{ $totalsellers }}</h4>
                      <p class="font-14 mb-0">Total sellers (active)</p>
                    </div>
                    <div class="col-4 animate__animated animate__fadeIn animate__delay-2s">
                      <a  href="{{ route('users.index',['filter' => 'sellers']) }}"> <i class="text-warning feather icon-users iconsize"></i>
                      </a>
                      </div>
                      
                  </div>
                </div>
            </div>
        </div>

        @endif

        <div class="col-md-3 ">
          <div class="card m-b-30 shadow-sm">
              <div class="card-body">
                <div class="row">
                  <div class="col-8">
                    <h4>{{ $total_testinonials }}</h4>
                    <p class="font-14 mb-0">Total Testimonials (active)</p>
                  </div>
                  <div class="col-4 animate__animated animate__fadeIn animate__delay-2s">
                    <a href="{{ route('testimonial.index') }}"> <i class="text-primary feather  icon-sliders iconsize"></i>
                    </a>
                    </div>
                    
                </div>
              </div>
          </div>
        </div>


        <div class="col-md-3 ">
          <div class="card m-b-30 shadow-sm">
              <div class="card-body">
                <div class="row">
                  <div class="col-8">
                    <h4>{{ $total_specialoffer }}</h4>
                    <p class="font-14 mb-0">Total Special offers (active)</p>
                  </div>
                  <div class="col-4 animate__animated animate__fadeIn animate__delay-2s">
                    <a  href="{{ route('special.index') }}"> <i class="text-info feather icon-gift iconsize"></i>
                    </a>
                    </div>
                    
                </div>
              </div>
          </div>
        </div>



        <div class="col-md-3 ">
          <div class="card m-b-30 shadow-sm">
              <div class="card-body">
                <div class="row">
                  <div class="col-8">
                    <h4>{{ $total_hotdeals }}</h4>
                    <p class="font-14 mb-0">Total Hotdeals (active)</p>
                  </div>
                  <div class="col-4 animate__animated animate__fadeIn animate__delay-2s">
                    <a href="{{ route('hotdeal.index') }}"> <i class="text-secondary feather icon-archive iconsize"></i>
                    </a>
                    </div>
                    
                </div>
              </div>
          </div>
       </div>



          <div class="col-md-12">
            {!! $orderchart->container() !!}
          </div>


          <div class="col-md-6 mt-4">
            <div class="card m-b-30">
                <div class="card-header">                                
                    <div class="row align-items-center">
                        <div class="col-9">
                            <h5 class="card-title mb-0">Visitors</h5>
                        </div>
                        <div class="col-3">
                          
                        </div>
                    </div>
                </div>
                <div class="card-body">
                  <div id="world-map" style="height: 350px; width: 100%;"></div>
                </div>
            </div>
          </div>
        
          <div class="col-md-6 mt-4">
            <div class="card p-2">
              {!! $userchart->container() !!}
            </div>
          </div>

            @if($dashsetting->lat_ord ==1)
            <div class="col-md-8">
              <div class="card m-b-30">
                  <div class="card-header">                                
                      <div class="row align-items-center">
                          <div class="col-9">
                              <h5 class="card-title mb-0">Latest Orders</h5>
                          </div>
                          <div class="col-3">
                              <div class="dropdown">
                                  <button class="btn btn-link p-0 font-18 float-right" type="button" id="upcomingTask" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><i class="feather icon-more-horizontal-"></i></button>
                                  <div class="dropdown-menu dropdown-menu-right" aria-labelledby="upcomingTask">
                                    @if(count($latestorders))
                                      <a class="dropdown-item font-13" href="{{ url('admin/order') }}">View All Orders</a>
                                      @endif
                                  </div>
                              </div>
                          </div>
                      </div>
                  </div>
                  <div class="card-body">
                      <div class="table-responsive">
                        <table class="table table-borderd">
                          <thead>
                            <tr>
                              <th>#</th>
                              <th>Order ID</th>
                              <th>Customer name</th>
                              <th>Total Qty</th>
                              <th>Total Price</th>
                              <th>Order Date</th>
                            </tr>
                          </thead>
                
                          <tbody>
                            @forelse($latestorders as $key=> $order)
                
                            <tr>
                              <td>{{$key+1}}</td>
                              <td><a title="View order"
                                  href="{{ route('show.order',$order->order_id) }}">#{{ $inv_cus->order_prefix.$order->order_id }}</a>
                              </td>
                              <td>{{ $order->user->name }}</td>
                              <td>{{ $order->qty_total }}</td>
                              <td><i class="{{ $order->paid_in }}"></i>{{ $order->order_total }}</td>
                              <td>{{ date('d-M-Y',strtotime($order->created_at)) }}</td>
                
                            </tr>
                            @empty
                              <tr>
                                <td colspan="6">
                                  {{  __("No orders found !") }}
                                </td>
                              </tr>
                            @endforelse
                          </tbody>
                        </table>
                      </div>
                  </div>
              </div>
            </div>
            @endif

            <div class="col-md-4">
              <div class="card">
                {!! $piechart->container() !!}
              </div>
            </div>


            @if($genrals_settings->vendor_enable == 1)
            @if($dashsetting->rct_str==1)
            <div class="col-md-12">
              <div class="card m-b-30">
                  <div class="card-header">                                
                      <div class="row align-items-center">
                          <div class="col-9">
                              <h5 class="card-title mb-0">Recent Store Requests</h5>
                          </div>
                          <div class="col-3">
                              <div class="dropdown">
                                  <button class="btn btn-link p-0 font-18 float-right" type="button" id="upcomingTask" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><i class="feather icon-more-horizontal-"></i></button>
                                  <div class="dropdown-menu dropdown-menu-right" aria-labelledby="upcomingTask">
                                    @if(count($storerequest))
                                      <a class="dropdown-item font-13" href="{{ url('admin/appliedform') }}">View All Store Request</a>
                                      @endif
                                  </div>
                              </div>
                          </div>
                      </div>
                  </div>
                  <div class="card-body">
                      <div class="table-responsive">
                        <table class="table table-borderd">
                          <thead>
                            <tr>
                              <th>#</th>
                              <th>Store Name</th>
                              <th>Buisness Email</th>
                              <th>Request By</th>
                            </tr>
                          </thead>
                
                          <tbody>
                
                            @forelse($storerequest as $key => $store)
                            <tr>
                              <td>{{$key + 1}}</td>
                              <td>{{ $store->name }}</td>
                              <td>{{ $store->email }}</td>
                              <td>{{ $store->owner }}</td>
                            </tr>
                            @empty
                              <tr>
                                <td align="center" colspan="4">
                                  <b>{{ __("No store request yet !") }}</b>
                                </td>
                              </tr>
                            @endforelse
                          </tbody>
                        </table>
                      </div>
                  </div>
              </div>
            </div>
            @endif
            @endif

            @if($dashsetting->rct_pro ==1)
            <div class="col-md-8">
              <div class="card m-b-30">
                  <div class="card-header">                                
                      <div class="row align-items-center">
                          <div class="col-9">
                              <h5 class="card-title mb-0">Recently Added Products</h5>
                          </div>
                          <div class="col-3">
                              <div class="dropdown">
                                  <button class="btn btn-link p-0 font-18 float-right" type="button" id="upcomingTask" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><i class="feather icon-more-horizontal-"></i></button>
                                  <div class="dropdown-menu dropdown-menu-right" aria-labelledby="upcomingTask">
                                  
                                      <a class="dropdown-item font-13" href="{{ url('admin/products') }}">View All Product</a>
                                    
                                  </div>
                              </div>
                          </div>
                      </div>
                  </div>
                  <div class="card-body">
                      <div class="row">
                        @foreach($products as $pro)
                        <div class="col-md-2 mt-2">
                          <img class="dashboard_image"
                          src="{{ $pro['thumbnail'] }}" title="{{ $pro['productname'] }}">
                        </div>
                        <div class="col-md-8">
                          <a href="{{ $pro['producturl'] }}" class="product-title"> {{ substr($pro['productname'],0,50)}}
                           </a><br>
                           <span class="product-description">
                            {{ substr($pro['detail'],0,50)}}{{strlen($pro['detail'])>50 ? "..." : "" }}
                          </span>
                        </div>
                        <div class="col-md-2">
                          <span class="badge badge-primary">
                            {{ $pro['price_in'] }} {{ $pro['price'] }}  
                          </span>
                          
                        </div>
                       
                      
                      @endforeach
                    </div>
                  </div>
              </div>
            </div>
            @endif

            @if($dashsetting->rct_cust ==1)
            <div class="col-md-4">
              <div class="card m-b-30">
                  <div class="card-header">                                
                      <div class="row align-items-center">
                          <div class="col-5">
                              <h5 class="card-title mb-0">Recent Users</h5>
                          </div>
                          <div class="col-7">
                            <div class="row">
                              <div class="col-md-10">
                                <span class="badge badge-success">{{ $registerTodayUsers }} members today</span>
                              </div>
                              <div class="col-md-2">
                            
                              <div class="dropdown">
                                
                                  <button class="btn btn-link p-0 font-18 float-right" type="button" id="widgetRevenue" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><i class="feather icon-more-horizontal-"></i></button>
                                  <div class="dropdown-menu dropdown-menu-right" aria-labelledby="widgetRevenue">
                                      <a class="dropdown-item font-13"  href="{{ route('users.index',['filter' => 'customer']) }}">View All Users</a>
                                
                                  </div>
                              </div>
                              </div>
                            </div>
                            
                          </div>
                      </div>
                  </div>                            
                  <div class="user-slider">
                    @foreach($users =
                    App\User::where('role_id','!=','a')->orderBy('id','DESC')->take($dashsetting->max_item_cust)->get() as
                    $user)
                      <div class="user-slider-item">
                          <div class="card-body text-center">
                              <span >
                                @if($user->image !="" && file_exists(public_path().'/images/user/'.$user->image))
                                <img class="mx-auto d-block user_image" src="{{ url('images/user/'.$user->image)  }}" alt="">
                                @else
                                <img class="mx-auto d-block user_image" src="{{ Avatar::create($user->name)->tobase64() }}" alt="">
                                @endif
                              </span>
                              <h5 class="mt-3">{{ $user->name }}</h5>
                              <p>{{ $user->email }}</p>
                              <p><span class="badge badge-primary-inverse">{{ date('Y-m-d',strtotime($user->created_at)) }}</span></p>
                          </div>
                        </div>
                        @endforeach
                              
                          
                     
                    
                                                   
                  </div>                            
              </div>      
          </div>
          @endif

      

    
      </div>
    </div>
  </div>
</div>
@endsection

@section('custom-script')
<script src="{{ url('front/vendor/js/Chart.min.js') }}" charset="utf-8"></script>
<script src="{{ url('front/vendor/js/highcharts.js') }}" charset="utf-8"></script>

<script>
  $(function () {


    $.ajax({
      method: "GET",
      url: '{{ route("get.visitor.data") }}',
      success: function (response) {
        console.log(response);

        $('#world-map').vectorMap({
          map: 'world_mill_en',
          backgroundColor: 'transparent',
          regionStyle: {
            initial: {
              fill: '#e4e4e4',
              'fill-opacity': 1,
              stroke: 'none',
              'stroke-width': 0,
              'stroke-opacity': 1
            }
          },
          series: {
            regions: [{
              values: response,
              scale: ['#f9b9be', '#fbdca2','#6fdca4'],
              normalizeFunction: 'polynomial'
            }]
          },
          onRegionLabelShow: function (e, el, code) {
            if (typeof response[code] != 'undefined') {
              el.html(el.html() + ': ' + response[code] + ' visitors');
            } else {
              el.html(el.html() + ': ' + '0' + ' visitors');
            }

          }
        });

      },
      error: function (err) {
        console.log('Error:' + err);
      }
    });


  });
</script>
{!! $userchart->script() !!}
{!! $piechart->script() !!}
{!! $orderchart->script() !!}
@endsection
  
     
         
           

