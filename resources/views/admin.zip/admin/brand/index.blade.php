@extends('admin.layouts.master-soyuz')
@section('title','All Brands')
@section('body')
@component('admin.component.breadcumb',['secondaryactive' => 'active'])
@slot('heading')
   {{ __('All Brands') }}
@endslot

@slot('menu1')
   {{ __('Brands') }}
@endslot

@slot('button')

<div class="col-md-6">
    <div class="widgetbar">
        <a  href=" {{url('admin/brand/create')}} " class="float-right btn btn-primary-rgba mr-2">
            <i class="feather icon-plus mr-2"></i> {{__("Add Brands")}}
        </a>
    </div>                        
</div>
@endslot
@endcomponent
<div class="contentbar"> 
    <div class="row">
        
        <div class="col-lg-12">
            <div class="card m-b-30">
                <div class="card-header">
                    <h5 class="box-title"> All  Brands</h5>
                </div>
                <div class="card-body">
                  <div class="table-responsive">
                    <table id="brandTable" class="width100 table table-bordered table-striped">
                      <thead>
                        <tr>
                          <th>Sr. No.</th>
                          <th>Brand Name</th>
                          <th>Brand Logo</th>
                          <th>Status</th>
                          <th>Action</th>
                        </tr>
                      </thead>
                      <tbody>
                
                      </tbody>
                    </table>
                  </div>
                </div>
            </div>
        </div>
    </div>
</div>
@foreach($brands as $brand)
<div class="modal fade bd-example-modal-sm" id="delete{{$brand->id}}" tabindex="-1" role="dialog" aria-hidden="true">
  <div class="modal-dialog modal-sm">
      <div class="modal-content">
          <div class="modal-header">
              <h5 class="modal-title" id="exampleSmallModalLabel">Delete</h5>
              <button type="button" class="close" data-dismiss="modal" aria-label="Close">
              <span aria-hidden="true">&times;</span>
              </button>
          </div>
          <div class="modal-body">
                  <h4>{{ __('Are You Sure ?')}}</h4>
                  <p>{{ __('Do you really want to delete')}}? {{ __('This process cannot be undone.')}}</p>
          </div>
          <div class="modal-footer">
              <form method="post" action="{{url('admin/brand/'.$brand->id)}}" class="pull-right">
                  {{csrf_field()}}
                  {{method_field("DELETE")}}
                  <button type="reset" class="btn btn-secondary" data-dismiss="modal">No</button>
                  <button type="submit" class="btn btn-primary">Yes</button>
              </form>
          </div>
      </div>
  </div>
</div>
@endforeach

@endsection
@section('custom-script')
<script>
  var url = @json(route('brand.index'));
</script>
<script src="{{ url('js/brand.js') }}"></script>
@endsection
