<form action="{{ route('brand.quick.update',$id) }}" method="POST">
      {{csrf_field()}}
   <span   @if(env('DEMO_LOCK') == 0) type="submit" @else disabled title="This operation is disabled in demo !" @endif class="btn btn-rounded {{ $status==1 ? "badge-success" : "badge-danger" }}">
        {{ $status ==1 ? 'Active' : 'Deactive' }}
   </span>
</form> 
