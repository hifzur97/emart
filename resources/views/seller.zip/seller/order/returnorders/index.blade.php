@extends('admin.layouts.sellermaster')
@section('title','Returned Orders |')
@section('body')

@component('seller.components.breadcumb',['secondactive' => 'active'])
@slot('heading')
   {{ __('Returned Orders s') }}
@endslot
@slot('menu1')
   {{ __('Returned Orders ') }}
@endslot



@endcomponent

<div class="contentbar">   
             
    <!-- Start row -->
    <div class="row">
    
        <div class="col-lg-12">
            <div class="card m-b-30">
                <div class="card-header">
                    <h5 class="card-title">{{ __('Returned Orders')}}</h5>
                </div>
				<div class="card-body">
					
					
				
					<ul class="nav nav-tabs custom-tab-line mb-3" id="defaultTabLine" role="tablist">
						<li class="nav-item">
							<a class="nav-link active" id="home-tab-line" data-toggle="tab" href="#home-line" role="tab" aria-controls="home-line" aria-selected="true"><i class="feather icon-truck mr-2"></i>
								Return Completed @if($countC>0) <span class="badge">{{$countC}}</span> @endif</a>
						</li>
						<li class="nav-item">
							<a class="nav-link" id="profile-tab-line" data-toggle="tab" href="#profile-line" role="tab" aria-controls="profile-line" aria-selected="false"><i class="feather icon-truck mr-2"></i>
								Pending Returns @if($countP>0) <span class="badge">{{$countP}}</span>@endif</a>
						</li>
						
					</ul>
					<div class="tab-content" id="defaultTabContentLine">
						<div class="tab-pane fade show active" id="home-line" role="tabpanel" aria-labelledby="home-tab-line">
							
							<table id="full_detail_table2" class="table table-striped w-100">
								<thead>
								
									<th>
										#
									</th>
									<th>
										Order ID
									</th>
									<th>
										Item
									</th>
									<th>
										Refunded Amount
									</th>
									<th>
										Refund Status
									</th>
	
								</thead>
								
								<tbody>
									@foreach($sellerorders as $key=> $order)
										
										@if($order->status != 'initiated')
										@if(isset($order->getorder->order))
										<tr>
											<td>
												{{ $key+1 }}
											</td>
											<td><b>#{{ $inv_cus->order_prefix.$order->getorder->order->order_id }}</b>
													<br>
													<small>
														<a title="View Refund Detail" href="{{  route('seller.order.detail',$order->id)  }}">View Detail</a> 
													</small>
											</td>
											<td>
												@php
													$findvar = App\AddSubVariant::withTrashed()->findorfail($order->getorder->variant_id);
	
	
													$varcount = count($findvar->main_attr_value);
													$i=0;
													  $var_name_count = count($findvar['main_attr_id']);
													  unset($name);
													  $name = array();
													  $var_name;
	
													$newarr = array();
													for($i = 0; $i<$var_name_count; $i++){
													  $var_id =$findvar['main_attr_id'][$i];
													  $var_name[$i] = $findvar['main_attr_value'][$var_id];
													   
														$name[$i] = App\ProductAttributes::where('id',$var_id)->first();
														
													}
	
	
												  try{
													$url = url(url('details').'/').'/'.$findvar->products->id.'?'.$name[0]['attr_name'].'='.$var_name[0].'&'.$name[1]['attr_name'].'='.$var_name[1];
												  }catch(Exception $e)
												  {
													$url = url(url('details').'/').'/'.$findvar->products->id.'?'.$name[0]['attr_name'].'='.$var_name[0];
												  }
	
												  @endphp
	
												
	
												<b><a target="_blank" title="{{ $findvar->products->name }} (@php
												
						 
												 $varcount = count($findvar->main_attr_value);
												 $var_main;
												 $i=0;
												  foreach ($findvar->main_attr_value as $key => $orivars) {
	
													  $i++;
	
													  $getattrname = App\ProductAttributes::where('id', $key)->first()->attr_name;
													  $getvarvalue = App\ProductValues::where('id', $orivars)->first();
	
													  if ($i < $varcount) {
														if (strcasecmp($getvarvalue->unit_value, $getvarvalue->values) != 0 && $getvarvalue->unit_value != null) {
														  if ($getvarvalue->proattr->attr_name == "Color" || $getvarvalue->proattr->attr_name == "Colour" || $getvarvalue->proattr->attr_name == "color" || $getvarvalue->proattr->attr_name == "colour") {
	
															echo $getvarvalue->values;
	
														  } else {
															echo $getvarvalue->values . $getvarvalue->unit_value.',';
														  }
														} else {
														  echo $getvarvalue->values;
														}
	
													  } else {
	
														if (strcasecmp($getvarvalue->unit_value, $getvarvalue->values) != 0 && $getvarvalue->unit_value != null) {
	
														  if ($getvarvalue->proattr->attr_name == "Color" || $getvarvalue->proattr->attr_name == "Colour" || $getvarvalue->proattr->attr_name == "color" || $getvarvalue->proattr->attr_name == "colour") {
	
															echo $getvarvalue->values;
														  } else {
															 echo $getvarvalue->values.$getvarvalue->unit_value;
														  }
	
														} else {
														  echo $getvarvalue->values;
														}
	
													  }
													} 
												@endphp)" href="{{ $url }}">{{substr($findvar->products->name, 0, 25)}}{{strlen($findvar->products->name)>25 ? '...' : ""}}
												(
	
												@php
												
						 
												 $varcount = count($findvar->main_attr_value);
												 $var_main;
												 $i=0;
												//var code
												  foreach ($findvar->main_attr_value as $key => $orivars) {
	
													  $i++;
	
													  $getattrname = App\ProductAttributes::where('id', $key)->first()->attr_name;
													  $getvarvalue = App\ProductValues::where('id', $orivars)->first();
	
													  if ($i < $varcount) {
														if (strcasecmp($getvarvalue->unit_value, $getvarvalue->values) != 0 && $getvarvalue->unit_value != null) {
														  if ($getvarvalue->proattr->attr_name == "Color" || $getvarvalue->proattr->attr_name == "Colour" || $getvarvalue->proattr->attr_name == "color" || $getvarvalue->proattr->attr_name == "colour") {
	
															echo $getvarvalue->values;
	
														  } else {
															echo $getvarvalue->values . $getvarvalue->unit_value.',';
														  }
														} else {
														  echo $getvarvalue->values;
														}
	
													  } else {
	
														if (strcasecmp($getvarvalue->unit_value, $getvarvalue->values) != 0 && $getvarvalue->unit_value != null) {
	
														  if ($getvarvalue->proattr->attr_name == "Color" || $getvarvalue->proattr->attr_name == "Colour" || $getvarvalue->proattr->attr_name == "color" || $getvarvalue->proattr->attr_name == "colour") {
	
															echo $getvarvalue->values;
														  } else {
															 echo $getvarvalue->values.$getvarvalue->unit_value;
														  }
	
														} else {
														  echo $getvarvalue->values;
														}
	
													  }
													} 
												@endphp)</a></b>	
											</td>
											<td>
												<i class="{{ $order->getorder->order->paid_in }}"></i>{{ $order->amount }}
											</td>
											<td>
												<label class="label label-success">
													{{ ucfirst($order->status) }}
												</label>
											</td>
										</tr>
										@endif
								
										@endif	
										
									@endforeach
									
								</tbody>
	
							</table>
						</div>
						<div class="tab-pane fade" id="profile-line" role="tabpanel" aria-labelledby="profile-tab-line">
							<table id="full_detail_table" class="table table-striped w-100">
								<thead>
									<th>
										#
									</th>
									<th>
										Order TYPE
									</th>
									<th>
										OrderID
									</th>
									<th>
										Pending Amount
									</th>
									<th>
										Requested By
									</th>
									<th>
										Requested on
									</th>
									
								</thead>
	
								<tbody>
									@foreach($sellerorders as $key=> $order)
										@if(isset($order->getorder->order) && $order->status == 'initiated')
											<tr>
												<td>{{ $key+1 }}</td>
												<td>
													@if($order->getorder->order->payment_method != 'COD')
														<label for="" class="label label-success">
															PREPAID
														</label>
													@else
														<label for="" class="label label-primary">
															COD
														</label>
													@endif
												</td>
												<td><b>#{{ $inv_cus->order_prefix.$order->getorder->order->order_id }}</b>
													<br>
													<small>
														<a title="Click to view" href="{{ route('seller.return.order.show',$order->id) }}">View Order</a>
													</small>
												</td>
												<td>
													<i class="{{ $order->getorder->order->paid_in }}"></i>{{ $order->amount }}
												</td>
												<td>
													{{ $order->user->name }}
												</td>
												<td>
													{{date('d-M-Y @ h:i A',strtotime($order->created_at))}}
												</td>
												
											</tr>
										@endif
									@endforeach
								</tbody>
							</table>
						</div>
						
					</div>
				</div>
               
          </div>
      </div>
      <!-- End col -->
  </div>
  
  @endsection

                 
  
               
  
          
              
              
             
              
             
            
                
              
    
                 
                

                
    
            
            
    
             
            
          





                                
 


